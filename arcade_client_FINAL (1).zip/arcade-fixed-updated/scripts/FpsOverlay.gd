extends CanvasLayer
## FpsOverlay.gd -- autoload, registered once in project.godot. Shows the
## current client-side framerate in the corner of every scene, so you can
## visually confirm the client is actually hitting its target rate
## alongside the server's own tick-rate/jitter console telemetry
## (qnx_match.c's PERF_REPORT_INTERVAL_S printout) -- client and server
## performance side by side for a demo, from two independent sources.

var label: Label

func _ready() -> void:
	layer = 100 # draw on top of whatever scene is active
	label = Label.new()
	label.position = Vector2(8, 8)
	label.add_theme_font_size_override("font_size", 14)
	label.add_theme_color_override("font_color", Color(0.6, 1.0, 0.6, 0.9))
	add_child(label)

func _process(_delta: float) -> void:
	label.text = "FPS: %d" % Engine.get_frames_per_second()
