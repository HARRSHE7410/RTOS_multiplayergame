extends Node
## Sfx.gd -- autoload, registered once in project.godot. Plays short
## procedurally-generated tones for game events (no .wav/.ogg asset files
## needed -- everything here is synthesized on the fly with
## AudioStreamGenerator). This is client-side polish, not a QNX feature;
## it runs entirely in Godot on each player's own machine, same as the
## FPS overlay.
##
## Usage from any game script:
##   Sfx.beep(880.0, 0.08)          # short high beep -- e.g. paddle hit
##   Sfx.beep(220.0, 0.25)          # low longer tone -- e.g. wrong answer
##   Sfx.chord([523.0, 659.0, 784.0], 0.35)   # win/score fanfare

const SAMPLE_HZ := 44100.0

func beep(freq_hz: float, duration_s: float, volume: float = 0.35) -> void:
	_play_samples(_gen_tone(freq_hz, duration_s, volume))

func chord(freqs_hz: Array, duration_s: float, volume: float = 0.3) -> void:
	var n := int(SAMPLE_HZ * duration_s)
	var mixed := PackedFloat32Array()
	mixed.resize(n)
	for freq in freqs_hz:
		var wave := _gen_tone(freq, duration_s, volume / freqs_hz.size())
		for i in range(n):
			mixed[i] += wave[i]
	_play_samples(mixed)

func _gen_tone(freq_hz: float, duration_s: float, volume: float) -> PackedFloat32Array:
	var n := int(SAMPLE_HZ * duration_s)
	var samples := PackedFloat32Array()
	samples.resize(n)
	for i in range(n):
		# Simple envelope (quick fade in/out) so tones don't click at the edges.
		var t := float(i) / SAMPLE_HZ
		var env := 1.0
		var fade := 0.01
		if t < fade:
			env = t / fade
		elif duration_s - t < fade:
			env = (duration_s - t) / fade
		samples[i] = sin(TAU * freq_hz * t) * volume * env
	return samples

func _play_samples(samples: PackedFloat32Array) -> void:
	var player := AudioStreamPlayer.new()
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = SAMPLE_HZ
	gen.buffer_length = 0.5
	player.stream = gen
	add_child(player)
	player.play()
	var playback: AudioStreamGeneratorPlayback = player.get_stream_playback()
	# push_buffer() wants PackedVector2Array (one Vector2(left, right) per
	# frame, stereo) -- not the flat PackedFloat32Array _gen_tone()/chord()
	# work with internally. Duplicate each mono sample into both channels.
	var stereo := PackedVector2Array()
	stereo.resize(samples.size())
	for i in range(samples.size()):
		stereo[i] = Vector2(samples[i], samples[i])
	playback.push_buffer(stereo)
	# Clean up once playback finishes -- avoids leaking a Node per beep.
	var timer := get_tree().create_timer(samples.size() / SAMPLE_HZ + 0.1)
	timer.timeout.connect(func(): player.queue_free())
