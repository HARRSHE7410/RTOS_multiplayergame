extends Node2D
## TicTacToe.gd -- thin client for the tictactoe GameModule. The server is
## the sole judge of whose turn it is and what counts as a win; this just
## renders whatever STATE it's sent and forwards clicks as IN,<seat>,<cell>.

const JOIN_RETRY_INTERVAL := 1.0
const JOIN_MAX_ATTEMPTS := 10
const PING_INTERVAL := 1.0
const BOARD_ORIGIN := Vector2(160, 80)
const BOARD_SIZE := 480.0
const CELL_SIZE := BOARD_SIZE / 3.0

const NEON_CYAN := Color(0.1, 0.95, 1.0, 1.0)
const NEON_MAGENTA := Color(1.0, 0.2, 0.85, 1.0)

var udp := PacketPeerUDP.new()
var seat: int = -1
var awaiting_welcome := false
var join_attempts := 0
var time_since_join_attempt := 0.0

# Real RTT ping -- see SnakeArena.gd/Trivia.gd for the same pattern.
var ping_ms: float = -1.0
var ping_awaiting := false
var ping_sent_at_msec: int = 0
var time_since_ping := 999.0

var board: String = "........."
var turn: int = 0
var status: int = 0 # 0 playing, 1 win seat0, 2 win seat1, 3 draw
var result_text: String = ""
var series: Array[int] = [0, 0]
var left_until_msec: int = 0

var status_label: Label
var seat_label: Label
var ping_label: Label

func _ready() -> void:
	_build_ui()
	awaiting_welcome = true
	join_attempts = 0
	time_since_join_attempt = 999.0
	var err := udp.connect_to_host(Global.server_ip, Global.assigned_port)
	if err != OK:
		status_label.text = "Could not open socket to room."

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)

	var back_btn := Button.new()
	back_btn.text = "< Lobby"
	back_btn.position = Vector2(24, 16)
	back_btn.pressed.connect(func():
		udp.put_packet("LEAVE\n".to_utf8_buffer())
		Global.return_to_lobby()
	)
	layer.add_child(back_btn)

	var title := Label.new()
	title.text = "TIC-TAC-TOE -- Room %d" % Global.assigned_room_id
	title.position = Vector2(280, 16)
	title.add_theme_font_size_override("font_size", 20)
	title.add_theme_color_override("font_color", NEON_CYAN)
	layer.add_child(title)

	seat_label = Label.new()
	seat_label.position = Vector2(24, 560)
	layer.add_child(seat_label)

	ping_label = Label.new()
	ping_label.position = Vector2(660, 16)
	ping_label.add_theme_font_size_override("font_size", 12)
	ping_label.add_theme_color_override("font_color", Color(0.6, 1.0, 0.85, 0.95))
	layer.add_child(ping_label)

	status_label = Label.new()
	status_label.position = Vector2(220, 560)
	status_label.add_theme_color_override("font_color", NEON_MAGENTA)
	layer.add_child(status_label)

func _process(delta: float) -> void:
	if awaiting_welcome:
		_try_join(delta)

	while udp.get_available_packet_count() > 0:
		var line := udp.get_packet().get_string_from_utf8().strip_edges()
		if line != "":
			_handle_line(line)

	seat_label.text = "You are: %s" % ("X (cyan)" if seat == 0 else ("O (magenta)" if seat == 1 else "spectating"))
	if seat >= 0:
		_send_ping(delta)
	ping_label.text = ("ping: %.0fms" % ping_ms) if ping_ms >= 0.0 else "ping: --"
	if Time.get_ticks_msec() < left_until_msec:
		status_label.text = "A player left. Waiting for a new one..."
	elif seat >= 0:
		status_label.text = "Series: X %d - O %d" % [series[0], series[1]]
	queue_redraw()

func _try_join(delta: float) -> void:
	time_since_join_attempt += delta
	if time_since_join_attempt < JOIN_RETRY_INTERVAL:
		return
	if join_attempts >= JOIN_MAX_ATTEMPTS:
		status_label.text = "No response from the room."
		awaiting_welcome = false
		return
	udp.put_packet("JOIN\n".to_utf8_buffer())
	join_attempts += 1
	time_since_join_attempt = 0.0

func _send_ping(delta: float) -> void:
	time_since_ping += delta
	if time_since_ping < PING_INTERVAL:
		return
	time_since_ping = 0.0
	ping_sent_at_msec = Time.get_ticks_msec()
	ping_awaiting = true
	udp.put_packet(("PING,%d\n" % seat).to_utf8_buffer())

func _handle_line(line: String) -> void:
	var parts := line.split(",")
	match parts[0]:
		"PONG":
			if ping_awaiting:
				ping_ms = float(Time.get_ticks_msec() - ping_sent_at_msec)
				ping_awaiting = false
		"WELCOME":
			seat = int(parts[1])
			awaiting_welcome = false
			status_label.text = ""
		"FULL":
			awaiting_welcome = false
			status_label.text = "Room is full -- spectating not yet supported, go back and try another room."
		"STATE":
			board = parts[1]
			turn = int(parts[2])
			status = int(parts[3])
			if parts.size() > 5:
				series[0] = int(parts[4])
				series[1] = int(parts[5])
		"WIN":
			var w := int(parts[1])
			result_text = "%s WINS!" % ("X" if w == 0 else "O")
			Sfx.chord([523.0, 659.0, 784.0], 0.35)
		"DRAW":
			result_text = "DRAW!"
			Sfx.beep(220.0, 0.3)
		"MATCH_WIN":
			var mw := int(parts[1])
			result_text = "%s WINS THE MATCH!" % ("X" if mw == 0 else "O")
			Sfx.chord([523.0, 659.0, 784.0, 1046.0], 0.5)
		"OPPONENT_LEFT":
			left_until_msec = Time.get_ticks_msec() + 5000

func _unhandled_input(event: InputEvent) -> void:
	if seat < 0 or status != 0:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if seat != turn:
			return
		var mb := event as InputEventMouseButton
		var local := mb.position - BOARD_ORIGIN
		if local.x < 0 or local.y < 0 or local.x >= BOARD_SIZE or local.y >= BOARD_SIZE:
			return
		var col := int(local.x / CELL_SIZE)
		var row := int(local.y / CELL_SIZE)
		var cell := row * 3 + col
		if cell >= 0 and cell < 9 and board[cell] == ".":
			udp.put_packet(("IN,%d,%d\n" % [seat, cell]).to_utf8_buffer())
			Sfx.beep(660.0, 0.06)

func _draw() -> void:
	draw_rect(Rect2(BOARD_ORIGIN, Vector2(BOARD_SIZE, BOARD_SIZE)), Color(0.08, 0.09, 0.13, 1.0))
	for i in range(1, 3):
		draw_line(BOARD_ORIGIN + Vector2(i * CELL_SIZE, 0), BOARD_ORIGIN + Vector2(i * CELL_SIZE, BOARD_SIZE), NEON_CYAN, 3.0)
		draw_line(BOARD_ORIGIN + Vector2(0, i * CELL_SIZE), BOARD_ORIGIN + Vector2(BOARD_SIZE, i * CELL_SIZE), NEON_CYAN, 3.0)

	for i in range(9):
		var c := board[i]
		if c == ".":
			continue
		var row := i / 3
		var col := i % 3
		var center := BOARD_ORIGIN + Vector2((col + 0.5) * CELL_SIZE, (row + 0.5) * CELL_SIZE)
		var pad := CELL_SIZE * 0.28
		if c == "0":
			draw_line(center + Vector2(-pad, -pad), center + Vector2(pad, pad), NEON_CYAN, 6.0)
			draw_line(center + Vector2(-pad, pad), center + Vector2(pad, -pad), NEON_CYAN, 6.0)
		else:
			draw_arc(center, pad, 0, TAU, 24, NEON_MAGENTA, 6.0)

	if status == 0 and seat >= 0:
		var turn_text := "YOUR MOVE" if turn == seat else "OPPONENT'S MOVE"
		draw_string(ThemeDB.fallback_font, Vector2(300, 60), turn_text, HORIZONTAL_ALIGNMENT_CENTER, -1, 18)
	elif result_text != "":
		draw_string(ThemeDB.fallback_font, Vector2(280, 60), result_text, HORIZONTAL_ALIGNMENT_CENTER, -1, 22)
