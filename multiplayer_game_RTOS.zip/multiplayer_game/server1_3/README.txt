QNX ARCADE - RUN STEPS (Pong, Tic-Tac-Toe, Shooter)
====================================================
Pi IP last used: 172.31.98.45   (re-check on the Pi with:  ifconfig )

A) BUILD (on the Windows laptop with QNX SDP 8.0)
  Momentics: File > Import > General > Existing Projects into Workspace > pick this folder (server1_3)
             right-click project > Build Configurations > Set Active > aarch64le-debug
             Project > Clean, then Build.  First console line must say "configuration aarch64le-debug".
  Output:    build/aarch64le-debug/server1_3
  (Command line alternative: run qnxsdp-env.bat from the qnx800 folder, then in this folder:  make clean && make )

B) COPY + RUN (Pi must be on the same network as the laptops)
  scp build/aarch64le-debug/server1_3 qnxuser@<PI_IP>:~/
  ssh qnxuser@<PI_IP>
  slay server1_3            (kills any old leftover rooms first)
  chmod +x server1_3
  ./server1_3 --mode=lobby  (leave this running; run it from the SAME folder every time)
  Expected: "[lobby] listening on UDP port 9000 ... games available: pong, tictactoe, shooter"

C) CLIENT (each laptop)
  Godot 4.6.x > open the arcade project folder > Run.
  IP box is pre-filled with 172.31.98.45 - change it if the Pi's IP is different > Connect.
  Laptop 1: "Create" a game.  Laptop 2: Refresh > Join the room.

D) IF SOMETHING FAILS
  Build error      -> send the FIRST error line.
  Client can't connect -> ping the Pi; same Wi-Fi/subnet? UDP ports 9000 and 9100+ must be reachable.
  Old rooms stuck  -> on the Pi:  slay server1_3  then start the lobby again.
  Emergency only: fallback/arcade_linux_x86_64 runs the same server on a Linux/WSL laptop (no QNX features).
