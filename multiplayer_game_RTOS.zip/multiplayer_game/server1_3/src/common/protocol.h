/*
 * protocol.h -- wire format + shared constants for the whole arcade.
 *
 * Two conversations happen over plain-text, newline-terminated UDP:
 *
 *   Client <-> Lobby (well-known port, default 9000)
 *     LIST                    -> GAMES,<name1>,<name2>,...
 *     ROOMS                   -> ROOMS,<id>:<game>:<n>/<max>,...
 *     CREATE,<game>           -> ROOM,<room_id>,<port>  |  ERR,<reason>
 *     JOIN,<room_id>          -> ROOM,<room_id>,<port>  |  ERR,<reason>
 *
 *   Client <-> Match (ephemeral port handed out by ROOM,...)
 *     JOIN                    -> WELCOME,<seat>  |  FULL
 *     IN,<seat>,<payload>     game-specific input, no reply
 *     PING,<seat>             -> PONG                (keepalive; refreshes
 *                                                      last_seen without
 *                                                      counting as game
 *                                                      input -- send this on
 *                                                      an interval well
 *                                                      under CLIENT_TIMEOUT_S,
 *                                                      e.g. every 2-3s, so
 *                                                      idle_ok games like
 *                                                      Trivia don't reap a
 *                                                      quiet-but-connected
 *                                                      player)
 *     ...                     -> STATE,... / other game-specific broadcasts
 */
#ifndef ARCADE_PROTOCOL_H
#define ARCADE_PROTOCOL_H

#define LOBBY_PORT_DEFAULT   9000
#define MATCH_PORT_BASE      9100
#define MAX_LINE             1024
#define MAX_ROOMS            32
#define MAX_PLAYERS_PER_ROOM 4
#define CLIENT_TIMEOUT_S     8.0

#endif
