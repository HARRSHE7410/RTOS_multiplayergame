#include "room_ipc.h"

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdint.h>

#if defined(__QNX__)
static void room_ipc_channel_name(int room_id, char *out, size_t out_sz) {
	snprintf(out, out_sz, "qnx_arcade/room_%d_ctrl", room_id);
}
#endif

#if defined(__QNX__)

/* Message content doesn't matter for this use case -- any message
 * arriving on the channel means "please shut down". A real header struct
 * (type/subtype) is kept anyway since it's the conventional QNX message
 * shape and leaves room to add more request types later without
 * changing the wire format. */
typedef struct {
	uint16_t type;
	uint16_t subtype;
} RoomIpcMsgHdr;

int room_ipc_server_open(RoomIpcServer *srv, int room_id) {
	char name[64];
	room_ipc_channel_name(room_id, name, sizeof(name));
	srv->attach = name_attach(NULL, name, 0);
	return srv->attach ? 0 : -1;
}

void room_ipc_server_wait_shutdown(RoomIpcServer *srv) {
	if (!srv->attach) return;
	for (;;) {
		RoomIpcMsgHdr msg;
		int rcvid = MsgReceive(srv->attach->chid, &msg, sizeof(msg), NULL);
		if (rcvid < 0) {
			if (errno == EINTR) continue;
			/* Channel torn down (room_ipc_server_close ran, likely from
			 * a normal SIGTERM shutdown path) or a real error -- either
			 * way, stop waiting. */
			return;
		}
		if (rcvid == 0) {
			/* A pulse, not a real message -- this channel doesn't use
			 * pulses, but MsgReply() on a pulse is invalid, so skip it. */
			continue;
		}
		MsgReply(rcvid, EOK, NULL, 0);
		return;
	}
}

void room_ipc_server_close(RoomIpcServer *srv) {
	if (srv->attach) name_detach(srv->attach, 0);
	srv->attach = NULL;
}

int room_ipc_request_shutdown(int room_id) {
	char name[64];
	room_ipc_channel_name(room_id, name, sizeof(name));
	int coid = name_open(name, 0);
	if (coid == -1) return -1;
	RoomIpcMsgHdr msg;
	msg.type = 0;
	msg.subtype = 0;
	int rc = MsgSend(coid, &msg, sizeof(msg), NULL, 0);
	name_close(coid);
	return rc == -1 ? -1 : 0;
}

#else /* portable stub: always "unsupported", callers fall back to SIGTERM */

int room_ipc_server_open(RoomIpcServer *srv, int room_id) {
	(void)srv; (void)room_id;
	return -1;
}

void room_ipc_server_wait_shutdown(RoomIpcServer *srv) {
	(void)srv;
	/* Never called in practice off-QNX: match_main only spawns the IPC
	 * thread when room_ipc_server_open() succeeds, which never happens
	 * here. Returning immediately (rather than blocking forever) is the
	 * safe behavior if it somehow were called anyway. */
}

void room_ipc_server_close(RoomIpcServer *srv) {
	(void)srv;
}

int room_ipc_request_shutdown(int room_id) {
	(void)room_id;
	return -1;
}

#endif
