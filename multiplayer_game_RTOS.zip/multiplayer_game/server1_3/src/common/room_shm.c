#include "room_shm.h"

#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

static void shm_name(char *buf, size_t n, int room_id) {
	snprintf(buf, n, "/qnx_room_%d", room_id);
}

int room_shm_writer_open(RoomShmWriter *w, int room_id) {
	w->fd = -1;
	w->ptr = NULL;

	char name[64];
	shm_name(name, sizeof(name), room_id);

	/* Room IDs get reused (a slot frees up when a room exits, then a new
	 * CREATE reuses the same id) -- clear any stale segment a previous
	 * occupant of this id left behind before we start writing into it. */
	shm_unlink(name);

	int fd = shm_open(name, O_CREAT | O_RDWR, 0666);
	if (fd < 0) { perror("[room_shm] shm_open (writer)"); return -1; }

	if (ftruncate(fd, (off_t)sizeof(int)) != 0) {
		perror("[room_shm] ftruncate");
		close(fd);
		return -1;
	}

	void *ptr = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (ptr == MAP_FAILED) {
		perror("[room_shm] mmap (writer)");
		close(fd);
		return -1;
	}

	w->fd = fd;
	w->ptr = ptr;
	*(volatile int *)ptr = 0;
	return 0;
}

void room_shm_writer_set(RoomShmWriter *w, int count) {
	if (w->ptr) *(volatile int *)w->ptr = count;
}

void room_shm_writer_close(RoomShmWriter *w, int room_id) {
	if (w->ptr) munmap(w->ptr, sizeof(int));
	if (w->fd >= 0) close(w->fd);
	char name[64];
	shm_name(name, sizeof(name), room_id);
	shm_unlink(name);
	w->fd = -1;
	w->ptr = NULL;
}

int room_shm_read(int room_id, int *out_count) {
	char name[64];
	shm_name(name, sizeof(name), room_id);

	int fd = shm_open(name, O_RDONLY, 0666);
	if (fd < 0) return -1;

	void *ptr = mmap(NULL, sizeof(int), PROT_READ, MAP_SHARED, fd, 0);
	if (ptr == MAP_FAILED) { close(fd); return -1; }

	*out_count = *(volatile int *)ptr;
	munmap(ptr, sizeof(int));
	close(fd);
	return 0;
}
