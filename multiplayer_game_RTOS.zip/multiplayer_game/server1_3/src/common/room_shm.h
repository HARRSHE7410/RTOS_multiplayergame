#ifndef ARCADE_ROOM_SHM_H
#define ARCADE_ROOM_SHM_H

/*
 * room_shm.h -- tiny bit of POSIX shared memory that lets the lobby see a
 * match room's *live* connected-player count.
 *
 * Why this exists: the lobby's own Room.join_count (qnx_lobby.c) only
 * ever goes UP. The lobby never sees per-client LEAVE/timeout traffic --
 * only the match process (qnx_match.c) does, since clients talk to the
 * match process directly on its own port after JOIN hands them off. So
 * join_count drifts upward forever and the ROOMS listing (and the JOIN
 * full-check) both get stuck showing more players than are actually
 * connected.
 *
 * Fix: each match process publishes ms->num_connected into a small shm
 * segment named "/qnx_room_<id>" every time it actually changes (join,
 * leave, timeout). The lobby reads that segment (read-only, best-effort)
 * whenever it answers ROOMS or JOIN, and falls back to join_count only if
 * the segment isn't there yet (the brief window right after CREATE,
 * before the freshly-forked child has opened its own segment).
 */

typedef struct {
	int   fd;
	void *ptr;
} RoomShmWriter;

/* Match process side. Call once after room_id is known. Returns 0 on
 * success; on failure w->ptr is NULL and writer_set() becomes a no-op, so
 * callers don't need to check the return value at every call site. */
int room_shm_writer_open(RoomShmWriter *w, int room_id);

/* Publish the current live connected-player count. Cheap, call it
 * whenever num_connected changes. */
void room_shm_writer_set(RoomShmWriter *w, int count);

/* Unmap and remove the segment. Call on clean match-process shutdown. */
void room_shm_writer_close(RoomShmWriter *w, int room_id);

/* Lobby side: best-effort read-only peek at a room's live count.
 * Returns 0 and fills *out_count on success, -1 if the segment doesn't
 * exist (room not up yet, or never published anything). */
int room_shm_read(int room_id, int *out_count);

#endif
