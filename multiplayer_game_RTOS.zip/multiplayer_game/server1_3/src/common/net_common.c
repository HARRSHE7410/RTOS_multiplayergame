#include "net_common.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <arpa/inet.h>

double now_seconds(void) {
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

int net_udp_bind(int port) {
	int fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0) { perror("socket"); return -1; }

	int reuse = 1;
	setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));

	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port = htons((uint16_t)port);

	if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		perror("bind");
		close(fd);
		return -1;
	}
	return fd;
}

void net_send_line(int sock_fd, struct sockaddr_in *addr, const char *fmt, ...) {
	char buf[MAX_LINE];
	va_list args;
	va_start(args, fmt);
	int len = vsnprintf(buf, sizeof(buf) - 1, fmt, args);
	va_end(args);
	if (len <= 0) return;
	buf[len] = '\n';
	sendto(sock_fd, buf, (size_t)len + 1, 0, (struct sockaddr *)addr, sizeof(*addr));
}

void net_send_to_seat(int sock_fd, Peer *peers, int seat, const char *fmt, ...) {
	if (seat < 0 || !peers[seat].connected) return;
	char buf[MAX_LINE];
	va_list args;
	va_start(args, fmt);
	int len = vsnprintf(buf, sizeof(buf) - 1, fmt, args);
	va_end(args);
	if (len <= 0) return;
	buf[len] = '\n';
	sendto(sock_fd, buf, (size_t)len + 1, 0, (struct sockaddr *)&peers[seat].addr, sizeof(peers[seat].addr));
}

void net_broadcast_line(int sock_fd, Peer *peers, int max_peers, const char *fmt, ...) {
	char buf[MAX_LINE];
	va_list args;
	va_start(args, fmt);
	int len = vsnprintf(buf, sizeof(buf) - 1, fmt, args);
	va_end(args);
	if (len <= 0) return;
	buf[len] = '\n';
	for (int i = 0; i < max_peers; i++) {
		if (peers[i].connected) {
			sendto(sock_fd, buf, (size_t)len + 1, 0, (struct sockaddr *)&peers[i].addr, sizeof(peers[i].addr));
		}
	}
}

bool net_addr_eq(struct sockaddr_in *a, struct sockaddr_in *b) {
	return a->sin_addr.s_addr == b->sin_addr.s_addr && a->sin_port == b->sin_port;
}

int net_find_or_claim_seat(Peer *peers, int max_peers, struct sockaddr_in *from, bool claim_if_new) {
	for (int i = 0; i < max_peers; i++) {
		if (peers[i].connected && net_addr_eq(&peers[i].addr, from)) return i;
	}
	if (!claim_if_new) return -1;
	for (int i = 0; i < max_peers; i++) {
		if (!peers[i].connected) return i;
	}
	return -1;
}
