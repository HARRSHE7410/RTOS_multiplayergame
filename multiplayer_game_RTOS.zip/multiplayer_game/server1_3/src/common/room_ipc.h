/*
 * room_ipc.h -- real QNX synchronous message passing (ChannelCreate /
 * MsgReceive / MsgReply on the match side, name_open / MsgSend on the
 * lobby side), used for one thing: a graceful shutdown handshake.
 *
 * This exists specifically to give the arcade a genuine QNX IPC story
 * distinct from room_shm.h. room_shm is a *shared-memory* mechanism (the
 * match process writes a number, the lobby reads it whenever it feels
 * like it -- no synchronization, no acknowledgment). This module is real
 * QNX message passing: the lobby's MsgSend() call physically blocks
 * until the target match process's MsgReceive() picks the message up and
 * MsgReply()s to it. That's a synchronous "I confirm I got this and I'm
 * acting on it" guarantee that fire-and-forget signals (SIGTERM) or
 * shared memory simply don't give you.
 *
 * Off-QNX (Linux/macOS dev builds), every function here is a no-op stub
 * that always reports "unsupported" -- callers are expected to fall back
 * to SIGTERM in that case, exactly like the SCHED_RR fallback elsewhere
 * in this codebase.
 */
#ifndef ARCADE_ROOM_IPC_H
#define ARCADE_ROOM_IPC_H

#if defined(__QNX__)
#include <sys/neutrino.h>
#include <sys/dispatch.h>
typedef struct { name_attach_t *attach; } RoomIpcServer;
#else
typedef struct { int unused; } RoomIpcServer;
#endif

/* Match-process side: opens this room's shutdown channel under a name
 * derived from room_id. Returns 0 on success, -1 if unsupported (not on
 * QNX) or the name is already taken/can't be attached. On -1, do NOT
 * spawn a thread to wait on it -- there's nothing to wait on. */
int room_ipc_server_open(RoomIpcServer *srv, int room_id);

/* Blocks until exactly one shutdown request arrives on this channel (or
 * the channel is torn down / a real error occurs), replies to it, then
 * returns. Meant to run in its own dedicated thread; the caller decides
 * what "shut down" means afterward (e.g. clearing its own run flag). */
void room_ipc_server_wait_shutdown(RoomIpcServer *srv);

/* Detaches the channel. Safe to call even if open() failed. Calling this
 * is also what unblocks a thread currently parked in
 * room_ipc_server_wait_shutdown() during normal (non-IPC-triggered)
 * shutdown, e.g. after a SIGTERM -- MsgReceive() errors out once the
 * channel it's listening on is detached, letting that thread exit and
 * be joined instead of hanging forever waiting for a message that will
 * now never come. */
void room_ipc_server_close(RoomIpcServer *srv);

/* Lobby side. Blocks until the room's match process actually
 * acknowledges (real synchronous message passing, not fire-and-forget).
 * Returns 0 on confirmed acknowledgment, -1 if the room isn't reachable
 * via IPC (not on QNX, match process hasn't opened its channel yet, or
 * has already exited) -- callers should fall back to SIGTERM on -1. */
int room_ipc_request_shutdown(int room_id);

#endif
