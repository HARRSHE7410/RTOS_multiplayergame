/*
 * arcade_log.h -- routes server messages through QNX's native slog2
 * facility instead of plain printf, when built for QNX.
 *
 * Why this matters, concretely: printf on a busy console can BLOCK the
 * calling thread while the terminal/pipe catches up -- on a real-time
 * game-logic thread, that's a stall you can't afford, no different in
 * kind from any other unbounded-latency syscall. slog2 writes into a
 * lock-free ring buffer in shared memory and returns immediately; a
 * separate reader (slog2info) drains it whenever it feels like it,
 * completely decoupled from your thread's timing. It also survives a
 * crash (the ring buffer persists in shared memory), which a redirected
 * stdout log file doesn't if the write was still buffered when the
 * process died.
 *
 * View live on the target with:  slog2info -w
 * Or a one-shot dump with:       slog2info
 *
 * Off-QNX this reduces to plain printf so dev builds still show output.
 */
#ifndef ARCADE_LOG_H
#define ARCADE_LOG_H

#if defined(__QNX__)
#include <sys/slog2.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

static inline void arcade_log_init(const char *buffer_set_name) {
	slog2_buffer_t buffers[1];
	slog2_buffer_set_config_t config;
	memset(&config, 0, sizeof(config));
	config.num_buffers = 1;
	config.buffer_set_name = buffer_set_name;
	config.verbosity_level = SLOG2_INFO;
	config.buffer_config[0].buffer_name = "arcade";
	config.buffer_config[0].num_pages = 4; /* small is fine -- this is a demo arcade server, not a black box recorder */

	if (slog2_register(&config, buffers, 0) == 0) {
		slog2_set_default_buffer(buffers[0]);
	}
	/* On failure, slog2 calls silently no-op instead of crashing --
	 * intentionally left unhandled here so a permissions issue on the
	 * target doesn't take the whole arcade down over a logging facility. */
}

#define ARCADE_LOG(fmt, ...) \
	slog2f(NULL, 0, SLOG2_INFO, fmt, ##__VA_ARGS__)

#else /* portable fallback for dev builds */
#include <stdio.h>
static inline void arcade_log_init(const char *buffer_set_name) { (void)buffer_set_name; }
#define ARCADE_LOG(fmt, ...) printf(fmt "\n", ##__VA_ARGS__)
#endif

#endif
