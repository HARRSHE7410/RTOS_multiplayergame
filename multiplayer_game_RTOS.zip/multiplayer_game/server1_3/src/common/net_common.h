/*
 * net_common.h -- the bit of plumbing every game module would otherwise
 * reimplement: a peer table (who's in this room, on what seat, from what
 * address, when did we last hear from them) and printf-style send/broadcast
 * over UDP. Game modules never touch a socket directly -- they call these.
 */
#ifndef ARCADE_NET_COMMON_H
#define ARCADE_NET_COMMON_H

#include <netinet/in.h>
#include <stdbool.h>
#include <stddef.h>

#include "protocol.h"

typedef struct {
	bool connected;
	struct sockaddr_in addr;
	double last_seen;
} Peer;

double now_seconds(void);

int  net_udp_bind(int port);

void net_send_line(int sock_fd, struct sockaddr_in *addr, const char *fmt, ...);
void net_send_to_seat(int sock_fd, Peer *peers, int seat, const char *fmt, ...);
void net_broadcast_line(int sock_fd, Peer *peers, int max_peers, const char *fmt, ...);

bool net_addr_eq(struct sockaddr_in *a, struct sockaddr_in *b);

/* Finds an existing peer by address, or claims the first free seat if
 * `claim_if_new` is true. Returns seat index, or -1 if not found / full. */
int net_find_or_claim_seat(Peer *peers, int max_peers, struct sockaddr_in *from, bool claim_if_new);

#endif
