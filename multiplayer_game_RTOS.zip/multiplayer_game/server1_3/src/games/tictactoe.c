/* tictactoe.c -- 2-player, turn-based. Proves the lobby/room framework
 * generalizes past constant-tick-rate games like Pong: this ticks at 5Hz
 * (only for timeout bookkeeping) and does all its real work event-driven,
 * off client IN messages. */
#include "games.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BOARD_N 9
#define SERIES_WIN 3

typedef enum { TS_PLAYING, TS_WIN0, TS_WIN1, TS_DRAW } TTTStatus;

typedef struct {
	char      board[BOARD_N]; /* '.' empty, '0' seat0, '1' seat1 */
	int       turn;           /* whose move: 0 or 1 */
	TTTStatus status;
	double    reset_deadline; /* when status != PLAYING, reset after this */
	int       series[2];      /* round wins this match, first to SERIES_WIN takes it */
} TTTData;

static TTTData *td(MatchState *ms) { return (TTTData *)ms->game_data; }

static const int WIN_LINES[8][3] = {
	{0,1,2}, {3,4,5}, {6,7,8},
	{0,3,6}, {1,4,7}, {2,5,8},
	{0,4,8}, {2,4,6},
};

static void reset_board(TTTData *d) {
	memset(d->board, '.', BOARD_N);
	d->turn = 0;
	d->status = TS_PLAYING;
}

static TTTStatus check_winner(TTTData *d) {
	for (int i = 0; i < 8; i++) {
		char a = d->board[WIN_LINES[i][0]], b = d->board[WIN_LINES[i][1]], c = d->board[WIN_LINES[i][2]];
		if (a != '.' && a == b && b == c) return (a == '0') ? TS_WIN0 : TS_WIN1;
	}
	for (int i = 0; i < BOARD_N; i++) if (d->board[i] == '.') return TS_PLAYING;
	return TS_DRAW;
}

static void ttt_init(MatchState *ms) {
	TTTData *d = calloc(1, sizeof(TTTData));
	ms->game_data = d;
	reset_board(d);
}

static void ttt_on_join(MatchState *ms, int seat) {
	(void)seat;
	TTTData *d = td(ms);
	if (ms->num_connected <= 1) reset_board(d);
}

static void ttt_on_leave(MatchState *ms, int seat) {
	(void)seat;
	TTTData *d = td(ms);
	reset_board(d);
	if (ms->num_connected == 0) d->series[0] = d->series[1] = 0;
}

static void ttt_handle_input(MatchState *ms, int seat, const char *payload) {
	TTTData *d = td(ms);
	if (d->status != TS_PLAYING) return;
	if (seat != d->turn) return;
	int cell = -1;
	if (sscanf(payload, "%d", &cell) != 1) return;
	if (cell < 0 || cell >= BOARD_N) return;
	if (d->board[cell] != '.') return;

	d->board[cell] = (char)('0' + seat);
	d->status = check_winner(d);
	if (d->status == TS_PLAYING) {
		d->turn = 1 - d->turn;
	} else {
		d->reset_deadline = now_seconds() + 3.0;
		if (d->status == TS_WIN0) {
			d->series[0]++;
			net_broadcast_line(ms->sock_fd, ms->peers, 2, "WIN,0");
		} else if (d->status == TS_WIN1) {
			d->series[1]++;
			net_broadcast_line(ms->sock_fd, ms->peers, 2, "WIN,1");
		} else {
			net_broadcast_line(ms->sock_fd, ms->peers, 2, "DRAW");
		}
		if (d->series[0] >= SERIES_WIN || d->series[1] >= SERIES_WIN) {
			int mw = (d->series[0] >= SERIES_WIN) ? 0 : 1;
			net_broadcast_line(ms->sock_fd, ms->peers, 2, "MATCH_WIN,%d", mw);
			d->series[0] = d->series[1] = 0;
		}
	}
}

static void ttt_step(MatchState *ms, double dt) {
	(void)dt;
	TTTData *d = td(ms);
	if (d->status != TS_PLAYING && now_seconds() >= d->reset_deadline) {
		reset_board(d);
	}
}

static void ttt_broadcast(MatchState *ms) {
	TTTData *d = td(ms);
	char board_str[BOARD_N + 1];
	memcpy(board_str, d->board, BOARD_N);
	board_str[BOARD_N] = '\0';
	net_broadcast_line(ms->sock_fd, ms->peers, 2, "STATE,%s,%d,%d,%d,%d",
		board_str, d->turn, (int)d->status, d->series[0], d->series[1]);
}

const GameModule GAME_TICTACTOE = {
	.name = "tictactoe",
	.max_players = 2,
	.min_players_to_start = 2,
	.tick_hz = 20.0,
	.broadcast_hz = 20.0,
	.idle_ok = 0,
	.init = ttt_init,
	.on_join = ttt_on_join,
	.on_leave = ttt_on_leave,
	.handle_input = ttt_handle_input,
	.step = ttt_step,
	.broadcast_state = ttt_broadcast,
};
