/* pong.c -- 2-player Pong, ported into the GameModule interface. Rules and
 * feel are byte-for-byte identical to the original qnx_pong_server.c, so
 * the existing Godot Main.gd networking code needs no protocol changes. */
#include "games.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define ARENA_W        800.0f
#define ARENA_H        600.0f
#define ARENA_MARGIN   20.0f
#define PADDLE_HALF_H  55.0f
#define PADDLE_SPEED   420.0f
#define BALL_RADIUS    9.0f
#define BALL_START_V   320.0f
#define BALL_GAIN      22.0f
#define WIN_SCORE      7

typedef enum { RS_WAITING, RS_COUNTDOWN, RS_PLAYING, RS_SCORED } RoundState;

typedef struct {
	float input_dir[2];
	float paddle_y[2];
	int   score[2];
	float ball_x, ball_y, ball_vx, ball_vy;
	RoundState round_state;
	double countdown_deadline;
	int    countdown_value;
	int    serve_toward;
} PongData;

static PongData *pd(MatchState *ms) { return (PongData *)ms->game_data; }

static void reset_positions(PongData *d) {
	d->ball_x = ARENA_W / 2.0f;
	d->ball_y = ARENA_H / 2.0f;
	d->ball_vx = d->ball_vy = 0.0f;
	d->paddle_y[0] = d->paddle_y[1] = ARENA_H / 2.0f;
}

static void start_countdown(MatchState *ms, PongData *d) {
	d->round_state = RS_COUNTDOWN;
	d->countdown_value = 3;
	d->countdown_deadline = now_seconds() + 0.7;
	net_broadcast_line(ms->sock_fd, ms->peers, 2, "COUNTDOWN,%d", d->countdown_value);
}

static void launch_ball(MatchState *ms, PongData *d) {
	float angle = ((float)rand() / RAND_MAX) * 0.7f - 0.35f;
	d->ball_vx = cosf(angle) * BALL_START_V * (float)d->serve_toward;
	d->ball_vy = sinf(angle) * BALL_START_V;
	d->round_state = RS_PLAYING;
	net_broadcast_line(ms->sock_fd, ms->peers, 2, "GO");
}

static void handle_score(MatchState *ms, PongData *d, int scoring_seat) {
	d->score[scoring_seat]++;
	net_broadcast_line(ms->sock_fd, ms->peers, 2, "STATE,%.1f,%.1f,%.1f,%.1f,%d,%d",
		d->ball_x, d->ball_y, d->paddle_y[0], d->paddle_y[1], d->score[0], d->score[1]);
	if (d->score[scoring_seat] >= WIN_SCORE) {
		net_broadcast_line(ms->sock_fd, ms->peers, 2, "WIN,%d", scoring_seat);
		d->score[0] = d->score[1] = 0;
	}
	d->serve_toward = (scoring_seat == 0) ? 1 : -1;
	reset_positions(d);
	d->round_state = RS_SCORED;
	d->countdown_deadline = now_seconds() + 1.0;
}

static void pong_init(MatchState *ms) {
	PongData *d = calloc(1, sizeof(PongData));
	ms->game_data = d;
	srand((unsigned int)time(NULL) ^ (unsigned int)ms->port);
	reset_positions(d);
	d->serve_toward = 1;
	d->round_state = RS_WAITING;
}

static void pong_on_join(MatchState *ms, int seat) {
	(void)ms;
	PongData *d = pd(ms);
	d->score[seat] = 0;
	d->input_dir[seat] = 0.0f;
}

static void pong_on_leave(MatchState *ms, int seat) {
	PongData *d = pd(ms);
	d->input_dir[seat] = 0.0f;
	d->round_state = RS_WAITING;
}

static void pong_handle_input(MatchState *ms, int seat, const char *payload) {
	PongData *d = pd(ms);
	float dir = 0.0f;
	if (sscanf(payload, "%f", &dir) == 1) {
		if (dir > 1.0f) dir = 1.0f;
		if (dir < -1.0f) dir = -1.0f;
		d->input_dir[seat] = dir;
	}
}

static void pong_step(MatchState *ms, double dt) {
	PongData *d = pd(ms);
	for (int i = 0; i < 2; i++) {
		if (!ms->peers[i].connected) continue;
		d->paddle_y[i] += d->input_dir[i] * PADDLE_SPEED * (float)dt;
		float min_y = PADDLE_HALF_H + ARENA_MARGIN, max_y = ARENA_H - PADDLE_HALF_H - ARENA_MARGIN;
		if (d->paddle_y[i] < min_y) d->paddle_y[i] = min_y;
		if (d->paddle_y[i] > max_y) d->paddle_y[i] = max_y;
	}

	double t = now_seconds();
	if (d->round_state == RS_COUNTDOWN && t >= d->countdown_deadline) {
		d->countdown_value--;
		if (d->countdown_value > 0) {
			d->countdown_deadline = t + 0.7;
			net_broadcast_line(ms->sock_fd, ms->peers, 2, "COUNTDOWN,%d", d->countdown_value);
		} else {
			launch_ball(ms, d);
		}
	} else if (d->round_state == RS_SCORED && t >= d->countdown_deadline) {
		start_countdown(ms, d);
	} else if (d->round_state == RS_WAITING && ms->peers[0].connected && ms->peers[1].connected) {
		start_countdown(ms, d);
	}

	if (d->round_state != RS_PLAYING) return;

	d->ball_x += d->ball_vx * (float)dt;
	d->ball_y += d->ball_vy * (float)dt;

	if (d->ball_y < ARENA_MARGIN + BALL_RADIUS) {
		d->ball_y = ARENA_MARGIN + BALL_RADIUS;
		d->ball_vy = fabsf(d->ball_vy);
	} else if (d->ball_y > ARENA_H - ARENA_MARGIN - BALL_RADIUS) {
		d->ball_y = ARENA_H - ARENA_MARGIN - BALL_RADIUS;
		d->ball_vy = -fabsf(d->ball_vy);
	}

	float left_x = 60.0f, right_x = 740.0f, paddle_w = 16.0f;

	if (d->ball_vx < 0 && d->ball_x - BALL_RADIUS <= left_x + paddle_w / 2.0f &&
		d->ball_x > left_x && fabsf(d->ball_y - d->paddle_y[0]) <= PADDLE_HALF_H + BALL_RADIUS) {
		d->ball_x = left_x + paddle_w / 2.0f + BALL_RADIUS;
		float speed = sqrtf(d->ball_vx * d->ball_vx + d->ball_vy * d->ball_vy) + BALL_GAIN;
		float offset = (d->ball_y - d->paddle_y[0]) / PADDLE_HALF_H;
		float angle = offset * 0.6f;
		d->ball_vx = cosf(angle) * speed;
		d->ball_vy = sinf(angle) * speed;
	}
	if (d->ball_vx > 0 && d->ball_x + BALL_RADIUS >= right_x - paddle_w / 2.0f &&
		d->ball_x < right_x && fabsf(d->ball_y - d->paddle_y[1]) <= PADDLE_HALF_H + BALL_RADIUS) {
		d->ball_x = right_x - paddle_w / 2.0f - BALL_RADIUS;
		float speed = sqrtf(d->ball_vx * d->ball_vx + d->ball_vy * d->ball_vy) + BALL_GAIN;
		float offset = (d->ball_y - d->paddle_y[1]) / PADDLE_HALF_H;
		float angle = (float)M_PI - offset * 0.6f;
		d->ball_vx = cosf(angle) * speed;
		d->ball_vy = sinf(angle) * speed;
	}

	if (d->ball_x < -20.0f) handle_score(ms, d, 1);
	else if (d->ball_x > ARENA_W + 20.0f) handle_score(ms, d, 0);
}

static void pong_broadcast(MatchState *ms) {
	PongData *d = pd(ms);
	net_broadcast_line(ms->sock_fd, ms->peers, 2, "STATE,%.1f,%.1f,%.1f,%.1f,%d,%d",
		d->ball_x, d->ball_y, d->paddle_y[0], d->paddle_y[1], d->score[0], d->score[1]);
}

const GameModule GAME_PONG = {
	.name = "pong",
	.max_players = 2,
	.min_players_to_start = 2,
	.tick_hz = 60.0,
	.broadcast_hz = 30.0,
	.idle_ok = 0,
	.init = pong_init,
	.on_join = pong_on_join,
	.on_leave = pong_on_leave,
	.handle_input = pong_handle_input,
	.step = pong_step,
	.broadcast_state = pong_broadcast,
};
