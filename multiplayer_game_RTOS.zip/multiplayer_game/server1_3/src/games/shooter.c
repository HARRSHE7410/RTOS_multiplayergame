/* shooter.c -- 2-4 player top-down arena shooter. Server is authoritative
 * for movement, projectile spawn/travel, and hit detection -- a client
 * never gets to claim "I hit you", it only reports intent (move dir, aim
 * angle, firing). Runs at 60Hz, same tier as Pong. */
#include "games.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define ARENA_W       800.0f
#define ARENA_H       600.0f
#define MAX_SHOOTERS  4
#define MAX_BULLETS   64
#define PLAYER_SPEED  260.0f
#define PLAYER_R      16.0f
#define BULLET_SPEED  520.0f
#define BULLET_R      4.0f
#define FIRE_COOLDOWN 0.25
#define KILLS_TO_WIN  5

typedef struct { float x, y; } Vec2;

typedef struct {
	Vec2  pos;
	float aim_angle;
	int   alive;
	int   kills;
	int   deaths;
	double respawn_at;
	double last_fire_at;
	int   firing_requested;
} ShPlayer;

typedef struct {
	Vec2 pos, vel;
	int  owner;
	int  active;
} Bullet;

typedef struct {
	ShPlayer players[MAX_SHOOTERS];
	Bullet   bullets[MAX_BULLETS];
	int      round_over;
	double   reset_deadline;
} ShooterData;

static ShooterData *shd(MatchState *ms) { return (ShooterData *)ms->game_data; }

static const Vec2 SPAWNS[MAX_SHOOTERS] = { {80,80}, {720,520}, {720,80}, {80,520} };

static void respawn_player(ShPlayer *p, int seat) {
	p->pos = SPAWNS[seat];
	p->alive = 1;
	p->aim_angle = 0.0f;
	p->firing_requested = 0;
}

static void shooter_init(MatchState *ms) {
	ShooterData *d = calloc(1, sizeof(ShooterData));
	ms->game_data = d;
	srand((unsigned int)time(NULL) ^ (unsigned int)ms->port);
	for (int i = 0; i < MAX_SHOOTERS; i++) respawn_player(&d->players[i], i);
}

static void shooter_on_join(MatchState *ms, int seat) {
	ShooterData *d = shd(ms);
	respawn_player(&d->players[seat], seat);
	d->players[seat].kills = 0;
	d->players[seat].deaths = 0;
}

static void shooter_on_leave(MatchState *ms, int seat) {
	shd(ms)->players[seat].alive = 0;
}

/* Per-seat last requested move direction, cached between IN messages and
 * the next physics step (kept outside ShooterData since it's per-process
 * transient input state, not simulation state). */
static float g_move_dx[MAX_SHOOTERS];
static float g_move_dy[MAX_SHOOTERS];

static void shooter_handle_input(MatchState *ms, int seat, const char *payload) {
	ShooterData *d = shd(ms);
	ShPlayer *p = &d->players[seat];
	float dx = 0, dy = 0, angle = 0;
	int firing = 0;
	if (sscanf(payload, "%f,%f,%f,%d", &dx, &dy, &angle, &firing) != 4) return;
	if (dx > 1) dx = 1;
	if (dx < -1) dx = -1;
	if (dy > 1) dy = 1;
	if (dy < -1) dy = -1;
	g_move_dx[seat] = dx;
	g_move_dy[seat] = dy;
	p->aim_angle = angle;
	p->firing_requested = firing ? 1 : 0;
}

static void shooter_step(MatchState *ms, double dt) {
	ShooterData *d = shd(ms);
	double t = now_seconds();

	if (d->round_over) {
		if (t >= d->reset_deadline) {
			for (int i = 0; i < MAX_SHOOTERS; i++) {
				respawn_player(&d->players[i], i);
				d->players[i].kills = 0;
				d->players[i].deaths = 0;
			}
			memset(d->bullets, 0, sizeof(d->bullets));
			d->round_over = 0;
		}
		return;
	}

	for (int i = 0; i < MAX_SHOOTERS; i++) {
		ShPlayer *p = &d->players[i];
		if (!ms->peers[i].connected) continue;
		if (!p->alive) {
			if (p->respawn_at > 0 && t >= p->respawn_at) { respawn_player(p, i); }
			continue;
		}
		p->pos.x += g_move_dx[i] * PLAYER_SPEED * (float)dt;
		p->pos.y += g_move_dy[i] * PLAYER_SPEED * (float)dt;
		if (p->pos.x < PLAYER_R) p->pos.x = PLAYER_R;
		if (p->pos.x > ARENA_W - PLAYER_R) p->pos.x = ARENA_W - PLAYER_R;
		if (p->pos.y < PLAYER_R) p->pos.y = PLAYER_R;
		if (p->pos.y > ARENA_H - PLAYER_R) p->pos.y = ARENA_H - PLAYER_R;

		if (p->firing_requested && (t - p->last_fire_at) >= FIRE_COOLDOWN) {
			for (int b = 0; b < MAX_BULLETS; b++) {
				if (!d->bullets[b].active) {
					d->bullets[b].active = 1;
					d->bullets[b].owner = i;
					d->bullets[b].pos = p->pos;
					d->bullets[b].vel.x = cosf(p->aim_angle) * BULLET_SPEED;
					d->bullets[b].vel.y = sinf(p->aim_angle) * BULLET_SPEED;
					p->last_fire_at = t;
					break;
				}
			}
		}
	}

	for (int b = 0; b < MAX_BULLETS; b++) {
		Bullet *bl = &d->bullets[b];
		if (!bl->active) continue;
		bl->pos.x += bl->vel.x * (float)dt;
		bl->pos.y += bl->vel.y * (float)dt;
		if (bl->pos.x < 0 || bl->pos.x > ARENA_W || bl->pos.y < 0 || bl->pos.y > ARENA_H) {
			bl->active = 0;
			continue;
		}
		for (int i = 0; i < MAX_SHOOTERS; i++) {
			ShPlayer *p = &d->players[i];
			if (i == bl->owner || !p->alive || !ms->peers[i].connected) continue;
			float ddx = p->pos.x - bl->pos.x, ddy = p->pos.y - bl->pos.y;
			if (ddx * ddx + ddy * ddy <= (PLAYER_R + BULLET_R) * (PLAYER_R + BULLET_R)) {
				p->alive = 0;
				p->deaths++;
				p->respawn_at = t + 1.5;
				d->players[bl->owner].kills++;
				bl->active = 0;
				net_broadcast_line(ms->sock_fd, ms->peers, MAX_SHOOTERS, "FRAG,%d,%d", bl->owner, i);
				break;
			}
		}
	}

	for (int i = 0; i < MAX_SHOOTERS; i++) {
		if (d->players[i].kills >= KILLS_TO_WIN) {
			d->round_over = 1;
			d->reset_deadline = t + 3.0;
			net_broadcast_line(ms->sock_fd, ms->peers, MAX_SHOOTERS, "WIN,%d", i);
			break;
		}
	}
}

static void shooter_broadcast(MatchState *ms) {
	ShooterData *d = shd(ms);
	char players_str[400];
	int off = 0;
	for (int i = 0; i < MAX_SHOOTERS; i++) {
		ShPlayer *p = &d->players[i];
		off += snprintf(players_str + off, sizeof(players_str) - (size_t)off,
			"%d:%.1f:%.1f:%.2f:%d:%d;",
			ms->peers[i].connected, p->pos.x, p->pos.y, p->aim_angle, p->alive, p->kills);
	}
	char bullets_str[400];
	bullets_str[0] = '\0';
	off = 0;
	for (int b = 0; b < MAX_BULLETS; b++) {
		if (!d->bullets[b].active) continue;
		off += snprintf(bullets_str + off, sizeof(bullets_str) - (size_t)off,
			"%.1f:%.1f;", d->bullets[b].pos.x, d->bullets[b].pos.y);
	}
	net_broadcast_line(ms->sock_fd, ms->peers, MAX_SHOOTERS, "STATE,%s,%s", players_str, bullets_str);
}

const GameModule GAME_SHOOTER = {
	.name = "shooter",
	.max_players = MAX_SHOOTERS,
	.min_players_to_start = 2,
	.tick_hz = 60.0,
	.broadcast_hz = 30.0,
	.idle_ok = 0,
	.init = shooter_init,
	.on_join = shooter_on_join,
	.on_leave = shooter_on_leave,
	.handle_input = shooter_handle_input,
	.step = shooter_step,
	.broadcast_state = shooter_broadcast,
};
