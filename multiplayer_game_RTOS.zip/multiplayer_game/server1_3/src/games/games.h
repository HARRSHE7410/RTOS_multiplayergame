#ifndef ARCADE_GAMES_H
#define ARCADE_GAMES_H

#include "../match/game_module.h"

extern const GameModule GAME_PONG;
extern const GameModule GAME_TICTACTOE;
extern const GameModule GAME_SHOOTER;

#endif
