/*
 * qnx_lobby.c -- the one process every client talks to first. Answers
 * LIST/ROOMS, and on CREATE, fork()+exec()s a brand-new, independent
 * match process for a new room on its own UDP port. This is what makes
 * "2 people playing Pong in room 1 while 2 different people play Snake in
 * room 2, at the same time, on the same Pi" work: each room is a real OS
 * process the lobby supervises, not a thread or a simulated split.
 *
 * Crash isolation: if a match process dies (crash, kill -9, clean exit),
 * SIGCHLD fires, the lobby reaps it via waitpid(WNOHANG) and frees the
 * room slot. Other rooms are untouched -- same fork-supervision model as
 * the project's original watchdog, just scoped per-room instead of global.
 *
 * Deliberate design choice: a dead room is freed, not auto-respawned,
 * because respawning a fresh process can't restore who was seated or what
 * the score was -- clients would silently start talking to a blank room.
 * The exact spot to add auto-respawn (call spawn_room() again with the
 * same game/port) is marked below in reap_children().
 */
#include "qnx_lobby.h"
#include <sys/socket.h>
#include "../common/net_common.h"
#include "../common/protocol.h"
#include "../common/room_shm.h"
#include "../common/room_ipc.h"
#include "../match/game_registry.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/select.h>
#include <arpa/inet.h>

typedef struct {
	int    active;
	int    room_id;
	char   game[32];
	int    port;
	pid_t  pid;
	int    join_count; /* counts JOIN requests routed here; never
	                       decrements (the lobby doesn't see match-level
	                       LEAVE traffic). No longer used for ROOMS
	                       display or the FULL check -- see live_count()
	                       and room_shm.h -- kept only as a fallback for
	                       the brief window right after CREATE before the
	                       match process has published its own count. */
} Room;

static Room g_rooms[MAX_ROOMS];
static char g_self_path[1024];
static volatile sig_atomic_t g_sigchld_flag = 0;

static void on_sigchld(int sig) { (void)sig; g_sigchld_flag = 1; }

static int find_free_slot(void) {
	for (int i = 0; i < MAX_ROOMS; i++) if (!g_rooms[i].active) return i;
	return -1;
}

/* Prefer the match process's live, actually-decrementing count; fall back
 * to join_count only for the brief window right after CREATE before the
 * child has published its own segment (see room_shm.h). */
static int live_count(Room *r) {
	int count;
	if (room_shm_read(r->room_id, &count) == 0) return count;
	return r->join_count;
}

static Room *find_room(int room_id) {
	for (int i = 0; i < MAX_ROOMS; i++) {
		if (g_rooms[i].active && g_rooms[i].room_id == room_id) return &g_rooms[i];
	}
	return NULL;
}

static void reap_children(void) {
	int status;
	pid_t pid;
	while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
		for (int i = 0; i < MAX_ROOMS; i++) {
			if (g_rooms[i].active && g_rooms[i].pid == pid) {
				printf("[lobby] room %d (%s, pid %d) exited, freeing slot\n",
					g_rooms[i].room_id, g_rooms[i].game, (int)pid);
				g_rooms[i].active = 0;
				/* --- auto-respawn would go here ---
				 * spawn_room(g_rooms[i].game, g_rooms[i].room_id, g_rooms[i].port);
				 * Left out on purpose; see file header comment. */
			}
		}
	}
}

static int spawn_room(const char *game, int room_id, int port) {
	pid_t pid = fork();
	if (pid < 0) { perror("fork"); return -1; }
	if (pid == 0) {
		/* child: become a match process for this one room */
		char room_arg[32], port_arg[32], game_arg[1040];
		snprintf(room_arg, sizeof(room_arg), "--room=%d", room_id);
		snprintf(port_arg, sizeof(port_arg), "--port=%d", port);
		snprintf(game_arg, sizeof(game_arg), "--game=%s", game);
		char *argv[] = { g_self_path, "--mode=match", game_arg, port_arg, room_arg, NULL };
		execv(g_self_path, argv);
		perror("execv");
		_exit(127);
	}
	printf("[lobby] spawned room %d: game=%s port=%d pid=%d\n", room_id, game, port, (int)pid);
	return (int)pid;
}

static void handle_list(int sock_fd, struct sockaddr_in *from) {
	const char *names[16];
	int n = registry_list_names(names, 16);
	char buf[MAX_LINE];
	int off = snprintf(buf, sizeof(buf), "GAMES");
	for (int i = 0; i < n; i++) off += snprintf(buf + off, sizeof(buf) - (size_t)off, ",%s", names[i]);
	sendto(sock_fd, buf, (size_t)off, 0, (struct sockaddr *)from, sizeof(*from));
	sendto(sock_fd, "\n", 1, 0, (struct sockaddr *)from, sizeof(*from));
}

static void handle_rooms(int sock_fd, struct sockaddr_in *from) {
	char buf[MAX_LINE];
	int off = snprintf(buf, sizeof(buf), "ROOMS");
	for (int i = 0; i < MAX_ROOMS; i++) {
		if (!g_rooms[i].active) continue;
		const GameModule *gm = registry_find(g_rooms[i].game);
		int max_p = gm ? gm->max_players : 0;
		off += snprintf(buf + off, sizeof(buf) - (size_t)off, ",%d:%s:%d/%d",
			g_rooms[i].room_id, g_rooms[i].game, live_count(&g_rooms[i]), max_p);
	}
	sendto(sock_fd, buf, (size_t)off, 0, (struct sockaddr *)from, sizeof(*from));
	sendto(sock_fd, "\n", 1, 0, (struct sockaddr *)from, sizeof(*from));
}

static void handle_create(int sock_fd, struct sockaddr_in *from, char *game_name) {
	const GameModule *gm = registry_find(game_name);
	if (!gm) { net_send_line(sock_fd, from, "ERR,UNKNOWN_GAME"); return; }

	int slot = find_free_slot();
	if (slot < 0) { net_send_line(sock_fd, from, "ERR,LOBBY_FULL"); return; }

	int room_id = slot + 1;
	int port = MATCH_PORT_BASE + slot;
	int pid = spawn_room(game_name, room_id, port);
	if (pid < 0) { net_send_line(sock_fd, from, "ERR,SPAWN_FAILED"); return; }

	g_rooms[slot].active = 1;
	g_rooms[slot].room_id = room_id;
	strncpy(g_rooms[slot].game, game_name, sizeof(g_rooms[slot].game) - 1);
	g_rooms[slot].port = port;
	g_rooms[slot].pid = pid;
	g_rooms[slot].join_count = 1; /* the creator counts as the first join */

	net_send_line(sock_fd, from, "ROOM,%d,%d", room_id, port);
}

static void handle_join(int sock_fd, struct sockaddr_in *from, int room_id) {
	Room *r = find_room(room_id);
	if (!r) { net_send_line(sock_fd, from, "ERR,NO_ROOM"); return; }
	const GameModule *gm = registry_find(r->game);
	if (gm && live_count(r) >= gm->max_players) {
		net_send_line(sock_fd, from, "ERR,FULL");
		return;
	}
	/* join_count itself is now only a same-CREATE-window fallback (see
	 * live_count()) -- it's fine that it keeps climbing forever, nothing
	 * reads it once the room's shm segment is up. */
	r->join_count++;
	net_send_line(sock_fd, from, "ROOM,%d,%d", r->room_id, r->port);
}

static void handle_shutdown(int sock_fd, struct sockaddr_in *from, int room_id) {
	Room *r = find_room(room_id);
	if (!r) { net_send_line(sock_fd, from, "ERR,NO_ROOM"); return; }

	if (room_ipc_request_shutdown(room_id) == 0) {
		/* Real synchronous QNX message passing: by the time
		 * room_ipc_request_shutdown() returns 0, the match process has
		 * already MsgReply()'d -- meaning it genuinely received and
		 * acted on the request, not just "we sent a signal and hope". */
		net_send_line(sock_fd, from, "SHUTDOWN_OK,%d,ipc", room_id);
		return;
	}

	/* IPC unavailable (not on QNX, or the match process's channel isn't
	 * up) -- fall back to the blunter SIGTERM instrument. This still
	 * works everywhere, it just can't confirm the room actually acted on
	 * it before we return to the caller. */
	if (kill(r->pid, SIGTERM) == 0) {
		net_send_line(sock_fd, from, "SHUTDOWN_OK,%d,sigterm_fallback", room_id);
	} else {
		net_send_line(sock_fd, from, "ERR,SHUTDOWN_FAILED");
	}
}

static void handle_packet(int sock_fd, char *msg, struct sockaddr_in *from) {
	if (strcmp(msg, "LIST") == 0) { handle_list(sock_fd, from); return; }
	if (strcmp(msg, "ROOMS") == 0) { handle_rooms(sock_fd, from); return; }
	if (strncmp(msg, "CREATE,", 7) == 0) { handle_create(sock_fd, from, msg + 7); return; }
	if (strncmp(msg, "JOIN,", 5) == 0) { handle_join(sock_fd, from, atoi(msg + 5)); return; }
	if (strncmp(msg, "SHUTDOWN,", 9) == 0) { handle_shutdown(sock_fd, from, atoi(msg + 9)); return; }
}

int lobby_main(const char *self_path, int port) {
	strncpy(g_self_path, self_path, sizeof(g_self_path) - 1);
	memset(g_rooms, 0, sizeof(g_rooms));

	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = on_sigchld;
	sigaction(SIGCHLD, &sa, NULL);

	int sock_fd = net_udp_bind(port);
	if (sock_fd < 0) return 1;

	printf("[lobby] listening on UDP port %d, ready to spawn match rooms\n", port);
	{
		const char *names[16];
		int n = registry_list_names(names, 16);
		printf("[lobby] games available: ");
		for (int i = 0; i < n; i++) printf("%s%s", names[i], (i < n - 1) ? ", " : "\n");
	}

	char buf[MAX_LINE];
	struct sockaddr_in from;

	while (1) {
		if (g_sigchld_flag) { g_sigchld_flag = 0; reap_children(); }

		fd_set fds;
		FD_ZERO(&fds);
		FD_SET(sock_fd, &fds);
		struct timeval tv = { .tv_sec = 1, .tv_usec = 0 };

		int ready = select(sock_fd + 1, &fds, NULL, NULL, &tv);
		if (ready < 0) {
			if (errno == EINTR) continue;
			perror("select");
			continue;
		}
		if (ready > 0 && FD_ISSET(sock_fd, &fds)) {
			socklen_t from_len = sizeof(from);
			ssize_t n = recvfrom(sock_fd, buf, sizeof(buf) - 1, 0, (struct sockaddr *)&from, &from_len);
			if (n > 0) {
				buf[n] = '\0';
				char *nl = strpbrk(buf, "\r\n");
				if (nl) *nl = '\0';
				handle_packet(sock_fd, buf, &from);
			}
		}
	}

	close(sock_fd);
	return 0;
}
