#ifndef ARCADE_QNX_LOBBY_H
#define ARCADE_QNX_LOBBY_H

/* self_path: path to this same binary, used to fork+exec new match
 * processes (each room is a real, independent OS process). */
int lobby_main(const char *self_path, int port);

#endif
