/*
 * main.c -- one binary, two roles, decided by --mode:
 *
 *   qnx_arcade --mode=lobby [--port=9000]
 *       The one process every client talks to first.
 *
 *   qnx_arcade --mode=match --game=<name> --port=<n> --room=<id>
 *       One room, one game type, one UDP port, one OS process. The lobby
 *       launches these itself via fork()+exec() of this very binary --
 *       you never invoke --mode=match by hand except for debugging one
 *       room in isolation.
 *
 * Build:
 *   Linux/macOS (dev/testing): make
 *   QNX (Momentics or CLI):    make CC=qcc CFLAGS="-Vgcc_ntoarmv7le -O2" LIBS="-lsocket"
 *
 * Run on the Pi:
 *   ./qnx_arcade --mode=lobby
 * Then point every client's "server IP" field at the Pi; the client
 * speaks to the lobby first and gets redirected to whichever room it
 * creates or joins.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <fcntl.h>

#include "common/protocol.h"
#include "common/arcade_log.h"
#include "lobby/qnx_lobby.h"
#include "match/qnx_match.h"

static const char *arg_value(int argc, char **argv, const char *key) {
	size_t klen = strlen(key);
	for (int i = 1; i < argc; i++) {
		if (strncmp(argv[i], key, klen) == 0) return argv[i] + klen;
	}
	return NULL;
}

static void resolve_self_path(const char *argv0, char *out, size_t out_sz) {
#if defined(__QNX__)
	/* QNX's equivalent of Linux's /proc/self/exe -- a plain-text
	 * pseudo-file, not a symlink, so open()+read() not readlink(). */
	int fd = open("/proc/self/exefile", O_RDONLY);
	if (fd >= 0) {
		ssize_t n = read(fd, out, out_sz - 1);
		close(fd);
		if (n > 0) { out[n] = '\0'; return; }
	}
#elif defined(__linux__)
	ssize_t n = readlink("/proc/self/exe", out, out_sz - 1);
	if (n > 0) { out[n] = '\0'; return; }
#endif
	if (realpath(argv0, out) != NULL) return;
	strncpy(out, argv0, out_sz - 1);
	out[out_sz - 1] = '\0';
}

int main(int argc, char **argv) {
	arcade_log_init("qnx_arcade");
	const char *mode = arg_value(argc, argv, "--mode=");
	if (!mode) {
		fprintf(stderr,
			"usage:\n"
			"  %s --mode=lobby [--port=%d]\n"
			"  %s --mode=match --game=<name> --port=<n> --room=<id>\n",
			argv[0], LOBBY_PORT_DEFAULT, argv[0]);
		return 1;
	}

	char self_path[PATH_MAX];
	resolve_self_path(argv[0], self_path, sizeof(self_path));

	if (strcmp(mode, "lobby") == 0) {
		const char *port_str = arg_value(argc, argv, "--port=");
		int port = port_str ? atoi(port_str) : LOBBY_PORT_DEFAULT;
		return lobby_main(self_path, port);
	}

	if (strcmp(mode, "match") == 0) {
		const char *game = arg_value(argc, argv, "--game=");
		const char *port_str = arg_value(argc, argv, "--port=");
		const char *room_str = arg_value(argc, argv, "--room=");
		if (!game || !port_str || !room_str) {
			fprintf(stderr, "--mode=match requires --game=, --port=, and --room=\n");
			return 1;
		}
		return match_main(game, atoi(port_str), atoi(room_str));
	}

	fprintf(stderr, "unknown --mode=%s (expected 'lobby' or 'match')\n", mode);
	return 1;
}
