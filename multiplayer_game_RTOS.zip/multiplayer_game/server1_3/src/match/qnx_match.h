#ifndef ARCADE_QNX_MATCH_H
#define ARCADE_QNX_MATCH_H

int match_main(const char *game_name, int port, int room_id);

#endif
