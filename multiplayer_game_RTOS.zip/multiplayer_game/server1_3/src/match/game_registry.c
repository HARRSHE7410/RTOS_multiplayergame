#include "game_registry.h"
#include "../games/games.h"

#include <string.h>
#include <stddef.h>

static const GameModule *ALL_GAMES[] = {
	&GAME_PONG,
	&GAME_TICTACTOE,
	&GAME_SHOOTER,
};
static const int NUM_GAMES = (int)(sizeof(ALL_GAMES) / sizeof(ALL_GAMES[0]));

const GameModule *registry_find(const char *name) {
	for (int i = 0; i < NUM_GAMES; i++) {
		if (strcmp(ALL_GAMES[i]->name, name) == 0) return ALL_GAMES[i];
	}
	return NULL;
}

int registry_list_names(const char **out, int max) {
	int n = NUM_GAMES < max ? NUM_GAMES : max;
	for (int i = 0; i < n; i++) out[i] = ALL_GAMES[i]->name;
	return n;
}
