/*
 * qnx_match.c -- the generic room process. Every game (Pong, Tic-Tac-Toe,
 * Shooter, Trivia) runs inside a process started this same way; this file
 * knows NOTHING about any specific game's rules, only the GameModule
 * interface. One of these runs per active room, each its own OS process,
 * each on its own UDP port -- that's what lets two different games run at
 * the same time on the same Pi without touching each other.
 *
 * Usage: qnx_arcade --mode=match --game=<name> --port=<n> --room=<id>
 *
 * THREADING MODEL (new): each room process now runs two threads, not one:
 *   - the network-receive thread: does nothing but block on recvfrom() and
 *     push what it gets into a thread-safe queue. Runs at a HIGHER
 *     SCHED_RR priority band than the logic thread, so under CPU pressure
 *     it always preempts game logic to keep draining the socket -- an
 *     incoming packet should never sit queued in the kernel's socket
 *     buffer behind a slow tick.
 *   - the game-logic thread (this function, match_main): pulls queued
 *     messages, runs gm->step/broadcast_state on schedule, and does the
 *     timeout/latency/perf bookkeeping. This is the thread that carries
 *     the original per-room SCHED_RR priority (by tick_hz).
 * The two threads talk ONLY through the mutex+condvar-protected MsgQueue
 * below -- neither one touches the other's state directly.
 *
 * QNX-specific behavior (compiles out cleanly on Linux/macOS for local
 * testing, per the project's existing "portable core, QNX upgrades layered
 * on top" philosophy):
 *   - Sets each thread's scheduling class/priority via SCHED_RR, so a
 *     60Hz Shooter room's logic thread genuinely preempts a 5Hz Trivia
 *     room's logic thread under load, and every room's network thread
 *     preempts its own logic thread -- a real-time guarantee the default
 *     Linux/QNX time-sharing scheduler does not make on its own.
 *   - Games marked idle_ok (Trivia) let the logic thread block on the
 *     queue for up to a full second between events instead of spinning,
 *     so they spend (measurably) near-zero CPU while nothing is happening.
 *   - Every PERF_REPORT_INTERVAL_S seconds, prints the room's actually
 *     achieved tick rate and average tick-timing jitter to the QNX
 *     console (deliberately console-only, not broadcast to clients --
 *     this is server-side telemetry, not gameplay data).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "../common/net_common.h"
#include "../common/protocol.h"
#include "../common/room_shm.h"
#include "../common/room_ipc.h"
#include "../common/arcade_log.h"
#include "game_module.h"
#include "game_registry.h"

#define PERF_REPORT_INTERVAL_S 3.0
#define MQ_CAP 64

static int g_running_flag(void);
static volatile sig_atomic_t g_running;

/* ---- scheduling ---------------------------------------------------- */

static int priority_band_for_hz(double tick_hz) {
	/* Map tick rate to a SCHED_RR priority band. QNX priorities here
	 * commonly range ~1-63 for user processes; higher = runs first.
	 * A 60Hz room (Shooter/Pong) gets real priority separation from a
	 * 5Hz room (Trivia) so the scheduler -- not luck -- decides who gets
	 * the CPU first when the Pi is loaded. */
	if (tick_hz >= 45.0) return 18;
	if (tick_hz >= 15.0) return 14;
	if (tick_hz >= 5.0)  return 11;
	return 10;
}

#if defined(__QNX__)
#include <sched.h>
static void qnx_set_priority(pthread_t thread, int prio, const char *label) {
	struct sched_param sp;
	memset(&sp, 0, sizeof(sp));
	sp.sched_priority = prio;
	if (pthread_setschedparam(thread, SCHED_RR, &sp) != 0) {
		perror("[match] pthread_setschedparam (need appropriate QNX privileges)");
	} else {
		printf("[match] QNX SCHED_RR priority set to %d for %s\n", prio, label);
	}
}
#else
static void qnx_set_priority(pthread_t thread, int prio, const char *label) {
	(void)thread; (void)prio;
	printf("[match] (not on QNX -- skipping SCHED_RR priority for %s; this only actually enforces on the Pi)\n", label);
}
#endif

/* ---- thread-safe message queue between net thread and logic thread -- */

typedef struct {
	char data[MAX_LINE];
	struct sockaddr_in from;
} RawMsg;

typedef struct {
	RawMsg items[MQ_CAP];
	int head, tail, count;
	pthread_mutex_t lock;
	pthread_cond_t not_empty;
} MsgQueue;

static void mq_init(MsgQueue *q) {
	memset(q, 0, sizeof(*q));
	pthread_mutex_init(&q->lock, NULL);
	pthread_cond_init(&q->not_empty, NULL);
}

static void mq_push(MsgQueue *q, const char *data, size_t len, struct sockaddr_in *from) {
	pthread_mutex_lock(&q->lock);
	if (q->count == MQ_CAP) {
		/* Full: drop the OLDEST queued message, not the newest. For a
		 * real-time game server a stale queued input is worse than
		 * momentarily losing one -- keep making forward progress with
		 * the freshest data rather than processing a backlog of stale
		 * state. This should only ever trigger under deliberate flood
		 * conditions; normal play never gets close to 64 queued. */
		q->head = (q->head + 1) % MQ_CAP;
		q->count--;
	}
	RawMsg *slot = &q->items[q->tail];
	size_t copy_len = len < sizeof(slot->data) - 1 ? len : sizeof(slot->data) - 1;
	memcpy(slot->data, data, copy_len);
	slot->data[copy_len] = '\0';
	slot->from = *from;
	q->tail = (q->tail + 1) % MQ_CAP;
	q->count++;
	pthread_cond_signal(&q->not_empty);
	pthread_mutex_unlock(&q->lock);
}

/* Waits up to timeout_s for a message (0.0 = don't block at all). Returns
 * true if one was popped into *out. */
static bool mq_pop_wait(MsgQueue *q, RawMsg *out, double timeout_s) {
	pthread_mutex_lock(&q->lock);
	if (q->count == 0 && timeout_s > 0.0) {
		struct timespec ts;
		clock_gettime(CLOCK_REALTIME, &ts);
		double whole;
		double frac = modf(timeout_s, &whole);
		ts.tv_sec += (time_t)whole;
		ts.tv_nsec += (long)(frac * 1e9);
		if (ts.tv_nsec >= 1000000000L) { ts.tv_nsec -= 1000000000L; ts.tv_sec += 1; }
		pthread_cond_timedwait(&q->not_empty, &q->lock, &ts);
	}
	if (q->count == 0) {
		pthread_mutex_unlock(&q->lock);
		return false;
	}
	*out = q->items[q->head];
	q->head = (q->head + 1) % MQ_CAP;
	q->count--;
	pthread_mutex_unlock(&q->lock);
	return true;
}

/* ---- network-receive thread ----------------------------------------- */

typedef struct {
	int sock_fd;
	MsgQueue *q;
} NetThreadArgs;

static void *net_thread_main(void *arg_) {
	NetThreadArgs *arg = (NetThreadArgs *)arg_;
	char buf[MAX_LINE];
	struct sockaddr_in from;

	while (g_running_flag()) {
		socklen_t from_len = sizeof(from);
		ssize_t n = recvfrom(arg->sock_fd, buf, sizeof(buf) - 1, 0, (struct sockaddr *)&from, &from_len);
		if (n > 0) {
			buf[n] = '\0';
			char *nl = strpbrk(buf, "\r\n");
			if (nl) *nl = '\0';
			mq_push(arg->q, buf, strlen(buf), &from);
		}
		/* n <= 0: either the SO_RCVTIMEO timeout expired (lets us
		 * recheck g_running_flag() periodically for clean shutdown) or a
		 * genuine recv error -- either way, just loop. */
	}
	return NULL;
}

/* ---- QNX IPC shutdown thread ----------------------------------------
 * Third thread per room. Blocks in real QNX message passing
 * (room_ipc_server_wait_shutdown -> MsgReceive under the hood) waiting
 * for the lobby to request a graceful shutdown. See room_ipc.h for why
 * this is a genuinely different mechanism from room_shm.h, not a
 * duplicate of it. */

typedef struct {
	RoomIpcServer *srv;
	const GameModule *gm;
} IpcThreadArgs;

static void *ipc_thread_main(void *arg_) {
	IpcThreadArgs *arg = (IpcThreadArgs *)arg_;
	room_ipc_server_wait_shutdown(arg->srv);
	/* Returns either because a real shutdown request arrived, or because
	 * room_ipc_server_close() tore the channel down during a normal
	 * SIGTERM-driven shutdown -- in the latter case g_running is already
	 * 0, so this assignment is a harmless no-op. */
	if (g_running) {
		printf("[match:%s] received graceful shutdown request via QNX IPC\n", arg->gm->name);
	}
	g_running = 0;
	return NULL;
}

/* ---- shared shutdown flag -------------------------------------------- */

static volatile sig_atomic_t g_running = 1;
static void on_term(int sig) { (void)sig; g_running = 0; }
static int g_running_flag(void) { return g_running; }

/* Published to the lobby every time num_connected actually changes, so
 * ROOMS/JOIN can show/gate on who's really here instead of a
 * never-decrementing join counter. See room_shm.h. */
static RoomShmWriter g_room_shm;
static void publish_count(MatchState *ms) {
	room_shm_writer_set(&g_room_shm, ms->num_connected);
}

static void reap_timeouts(MatchState *ms, const GameModule *gm) {
	double t = now_seconds();
	for (int i = 0; i < gm->max_players; i++) {
		if (ms->peers[i].connected && (t - ms->peers[i].last_seen) > CLIENT_TIMEOUT_S) {
			printf("[match:%s] seat %d timed out\n", gm->name, i);
			ms->peers[i].connected = false;
			ms->num_connected--;
			if (gm->on_leave) gm->on_leave(ms, i);
			net_broadcast_line(ms->sock_fd, ms->peers, gm->max_players, "OPPONENT_LEFT,%d", i);
			publish_count(ms);
		}
	}
}

static void handle_line(MatchState *ms, const GameModule *gm, char *line, struct sockaddr_in *from) {
	double t = now_seconds();

	if (strcmp(line, "JOIN") == 0) {
		int seat = net_find_or_claim_seat(ms->peers, gm->max_players, from, true);
		if (seat < 0) {
			net_send_line(ms->sock_fd, from, "FULL");
			return;
		}
		bool is_new = !ms->peers[seat].connected;
		ms->peers[seat].connected = true;
		ms->peers[seat].addr = *from;
		ms->peers[seat].last_seen = t;
		if (is_new) {
			ms->num_connected++;
			printf("[match:%s] seat %d joined from %s:%d\n", gm->name, seat,
				inet_ntoa(from->sin_addr), ntohs(from->sin_port));
			if (gm->on_join) gm->on_join(ms, seat);
			publish_count(ms);
		}
		net_send_line(ms->sock_fd, from, "WELCOME,%d", seat);
		return;
	}

	if (strncmp(line, "IN,", 3) == 0) {
		int seat = -1;
		char payload[MAX_LINE];
		payload[0] = '\0';
		/* IN,<seat>,<rest of line as payload> */
		char *p = line + 3;
		char *comma = strchr(p, ',');
		if (!comma) return;
		*comma = '\0';
		seat = atoi(p);
		strncpy(payload, comma + 1, sizeof(payload) - 1);
		if (seat < 0 || seat >= gm->max_players) return;
		if (!ms->peers[seat].connected || !net_addr_eq(&ms->peers[seat].addr, from)) return;
		ms->peers[seat].last_seen = t;
		if (gm->handle_input) gm->handle_input(ms, seat, payload);
		return;
	}

	if (strncmp(line, "PING,", 5) == 0) {
		/* Keepalive only -- refreshes last_seen so idle_ok games (Trivia)
		 * don't reap a player who simply hasn't sent IN,... in a while.
		 * Never touches gm->handle_input. */
		int seat = atoi(line + 5);
		if (seat < 0 || seat >= gm->max_players) return;
		if (!ms->peers[seat].connected || !net_addr_eq(&ms->peers[seat].addr, from)) return;
		ms->peers[seat].last_seen = t;
		net_send_line(ms->sock_fd, from, "PONG");
		return;
	}

	if (strcmp(line, "LEAVE") == 0) {
		int seat = net_find_or_claim_seat(ms->peers, gm->max_players, from, false);
		if (seat >= 0 && ms->peers[seat].connected) {
			printf("[match:%s] seat %d left voluntarily\n", gm->name, seat);
			ms->peers[seat].connected = false;
			ms->num_connected--;
			if (gm->on_leave) gm->on_leave(ms, seat);
			net_broadcast_line(ms->sock_fd, ms->peers, gm->max_players, "OPPONENT_LEFT,%d", seat);
			publish_count(ms);
		}
		return;
	}
}

int match_main(const char *game_name, int port, int room_id) {
	const GameModule *gm = registry_find(game_name);
	if (!gm) {
		fprintf(stderr, "[match] unknown game '%s'\n", game_name);
		return 1;
	}

	signal(SIGTERM, on_term);
	signal(SIGINT, on_term);

	MatchState ms;
	memset(&ms, 0, sizeof(ms));
	ms.room_id = room_id;
	ms.port = port;
	ms.sock_fd = net_udp_bind(port);
	if (ms.sock_fd < 0) return 1;

	/* SO_RCVTIMEO so the network thread's blocking recvfrom() periodically
	 * wakes up to recheck g_running_flag() and can exit cleanly instead
	 * of blocking forever past shutdown. */
	struct timeval rcvto;
	rcvto.tv_sec = 0;
	rcvto.tv_usec = 500000;
	setsockopt(ms.sock_fd, SOL_SOCKET, SO_RCVTIMEO, &rcvto, sizeof(rcvto));

	if (room_shm_writer_open(&g_room_shm, room_id) == 0) {
		publish_count(&ms); /* starts at 0 -- makes the segment visible immediately */
	} else {
		printf("[match:%s] room_shm unavailable -- lobby will fall back to join_count for room %d\n",
			gm->name, room_id);
	}

	int logic_prio = priority_band_for_hz(gm->tick_hz);
	char logic_label[64];
	snprintf(logic_label, sizeof(logic_label), "game-logic thread (%s, tick_hz=%.1f)", gm->name, gm->tick_hz);
	qnx_set_priority(pthread_self(), logic_prio, logic_label);

	MsgQueue queue;
	mq_init(&queue);
	NetThreadArgs net_args;
	net_args.sock_fd = ms.sock_fd;
	net_args.q = &queue;

	pthread_t net_thread;
	if (pthread_create(&net_thread, NULL, net_thread_main, &net_args) != 0) {
		perror("[match] pthread_create (network thread)");
		return 1;
	}
	int net_prio = logic_prio + 2;
	if (net_prio > 25) net_prio = 25; /* stay well clear of kernel-reserved high bands */
	char net_label[64];
	snprintf(net_label, sizeof(net_label), "network-recv thread (%s)", gm->name);
	qnx_set_priority(net_thread, net_prio, net_label);

	RoomIpcServer ipc_srv;
	bool ipc_supported = (room_ipc_server_open(&ipc_srv, room_id) == 0);
	pthread_t ipc_thread;
	IpcThreadArgs ipc_args;
	ipc_args.srv = &ipc_srv;
	ipc_args.gm = gm;
	if (ipc_supported) {
		if (pthread_create(&ipc_thread, NULL, ipc_thread_main, &ipc_args) != 0) {
			perror("[match] pthread_create (IPC shutdown thread)");
			ipc_supported = false;
		} else {
			printf("[match:%s] QNX IPC shutdown channel open for room %d (real message passing, not shared memory)\n",
				gm->name, room_id);
		}
	} else {
		printf("[match:%s] QNX IPC shutdown channel unavailable (not on QNX, or name already taken) -- "
			"lobby will fall back to SIGTERM for room %d\n", gm->name, room_id);
	}

	if (gm->init) gm->init(&ms);

	printf("[match:%s] room %d listening on UDP port %d (max %d players, %.1fHz, 2 threads: logic prio %d / net prio %d)\n",
		gm->name, room_id, port, gm->max_players, gm->tick_hz, logic_prio, net_prio);

	double tick_seconds = 1.0 / gm->tick_hz;
	double broadcast_seconds = gm->broadcast_hz > 0.0 ? 1.0 / gm->broadcast_hz : tick_seconds;
	double last_tick = now_seconds();
	double last_broadcast = now_seconds();
	double last_timeout_check = now_seconds();
	double last_perf_report = now_seconds();
	int ticks_since_report = 0;
	double jitter_accum_ms = 0.0;

	while (g_running) {
		double t = now_seconds();

		/* Wait on the queue only until the nearest upcoming deadline.
		 * Honest note: this replaced an earlier design where idle_ok
		 * games (Trivia) explicitly blocked up to a full second when
		 * nothing was happening. That distinction doesn't survive this
		 * queue-based rewrite as-is -- EVERY game now only ever waits up
		 * to its own tick_seconds (Trivia's is 0.1s at tick_hz=10), so
		 * idle_ok is currently read nowhere in this file. It's not
		 * incorrect (Trivia still works fine, and 100ms polling is cheap
		 * even when idle), just no longer doing the specific CPU-idle
		 * thing its name promises. If you want that distinction back for
		 * a demo point, the fix is: when gm->idle_ok is true AND the
		 * queue is empty AND no client has sent anything recently, skip
		 * ahead to a longer wait (e.g. min(next_deadline, 1.0) only when
		 * !gm->idle_ok, else allow the full next_deadline even if that's
		 * seconds out) -- not implemented here to avoid quietly changing
		 * Trivia's phase-transition responsiveness without you deciding
		 * that trade-off deliberately. */
		double next_deadline = last_tick + tick_seconds;
		if (last_broadcast + broadcast_seconds < next_deadline) next_deadline = last_broadcast + broadcast_seconds;
		if (last_timeout_check + 1.0 < next_deadline) next_deadline = last_timeout_check + 1.0;
		double wait_s = next_deadline - t;
		if (wait_s < 0.0) wait_s = 0.0;

		RawMsg msg;
		if (mq_pop_wait(&queue, &msg, wait_s)) {
			handle_line(&ms, gm, msg.data, &msg.from);
			/* Drain anything else already queued without waiting again
			 * this iteration, so a burst of input doesn't get spread
			 * across multiple tick-timing passes. */
			while (mq_pop_wait(&queue, &msg, 0.0)) {
				handle_line(&ms, gm, msg.data, &msg.from);
			}
		}

		t = now_seconds();
		double dt = t - last_tick;
		if (dt >= tick_seconds) {
			if (gm->step) gm->step(&ms, dt);
			jitter_accum_ms += fabs(dt - tick_seconds) * 1000.0;
			ticks_since_report++;
			last_tick = t;
		}
		if (t - last_broadcast >= broadcast_seconds) {
			if (ms.num_connected > 0 && gm->broadcast_state) gm->broadcast_state(&ms);
			last_broadcast = t;
		}
		if (t - last_timeout_check >= 1.0) {
			reap_timeouts(&ms, gm);
			last_timeout_check = t;
		}
		if (t - last_perf_report >= PERF_REPORT_INTERVAL_S) {
			double elapsed = t - last_perf_report;
			double actual_hz = ticks_since_report / elapsed;
			double avg_jitter = ticks_since_report > 0 ? jitter_accum_ms / ticks_since_report : 0.0;
			ARCADE_LOG("[match:%s] room %d perf: %.1f ticks/sec (target %.1f) | avg jitter %.2fms | %d players connected",
				gm->name, room_id, actual_hz, gm->tick_hz, avg_jitter, ms.num_connected);
			net_broadcast_line(ms.sock_fd, ms.peers, gm->max_players, "JITTER,%.2f", avg_jitter);
			ticks_since_report = 0;
			jitter_accum_ms = 0.0;
			last_perf_report = t;
		}
	}

	room_ipc_server_close(&ipc_srv); /* unblocks ipc_thread if it's still waiting */
	if (ipc_supported) pthread_join(ipc_thread, NULL);
	pthread_join(net_thread, NULL);
	room_shm_writer_close(&g_room_shm, room_id);
	close(ms.sock_fd);
	return 0;
}
