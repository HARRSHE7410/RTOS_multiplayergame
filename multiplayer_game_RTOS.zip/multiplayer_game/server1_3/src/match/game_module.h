/*
 * game_module.h -- the ONE interface every game implements. qnx_match.c
 * (the generic per-room process) only ever calls through these six
 * function pointers; it never knows Pong from Snake from Trivia. To add a
 * new game you write one games/<name>.c implementing this struct and add
 * one line to game_registry.c -- nothing else in the engine changes.
 */
#ifndef ARCADE_GAME_MODULE_H
#define ARCADE_GAME_MODULE_H

#include "../common/net_common.h"
#include "../common/protocol.h"

typedef struct MatchState {
	int   sock_fd;
	int   room_id;
	int   port;
	Peer  peers[MAX_PLAYERS_PER_ROOM];
	int   num_connected;
	void *game_data;   /* game module owns and casts this itself */
} MatchState;

typedef struct GameModule {
	const char *name;
	int    max_players;
	int    min_players_to_start;
	double tick_hz;          /* how often step() runs                     */
	double broadcast_hz;     /* how often broadcast_state() runs           */
	int    idle_ok;          /* 1 = game is fine blocking on recv between
	                             ticks instead of busy-polling (Trivia);
	                             0 = needs a steady physics clock (Pong)   */

	/* Called once, right after the room process starts. Set up game_data,
	 * reset positions/scores/board, etc. */
	void (*init)(MatchState *ms);

	/* A client claimed a seat. seat is already recorded in ms->peers[]. */
	void (*on_join)(MatchState *ms, int seat);

	/* A seat timed out or explicitly left. */
	void (*on_leave)(MatchState *ms, int seat);

	/* Raw payload after "IN,<seat>," has been parsed off -- e.g. for
	 * "IN,0,-1.00" this receives seat=0, payload="-1.00". */
	void (*handle_input)(MatchState *ms, int seat, const char *payload);

	/* Advance simulation by dt seconds. Called at tick_hz. */
	void (*step)(MatchState *ms, double dt);

	/* Send whatever STATE/etc lines this game broadcasts. Called at
	 * broadcast_hz (usually lower than tick_hz to save bandwidth). */
	void (*broadcast_state)(MatchState *ms);
} GameModule;

#endif
