#ifndef ARCADE_GAME_REGISTRY_H
#define ARCADE_GAME_REGISTRY_H

#include "game_module.h"

/* Returns the module for `name`, or NULL if unknown. */
const GameModule *registry_find(const char *name);

/* Fills `out[]` (capacity `max`) with every registered game name, returns
 * how many were written. Used by the lobby to answer LIST. */
int registry_list_names(const char **out, int max);

#endif
