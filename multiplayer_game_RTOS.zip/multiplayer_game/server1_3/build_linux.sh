#!/bin/sh
# Emergency fallback ONLY (runs the same server on a normal Linux/WSL laptop, no QNX features).
gcc -Wall -pthread -Isrc -Isrc/common -Isrc/match -Isrc/games -Isrc/lobby $(find src -name "*.c") -o fallback/arcade_linux_x86_64 -lm -lrt
echo "built fallback/arcade_linux_x86_64  ->  run: ./fallback/arcade_linux_x86_64 --mode=lobby"
