extends Control
## Lobby.gd -- the QNX Arcade's front door. Everything here talks only to
## the lobby process (Global.lobby_port, default 9000). It never touches a
## match port directly: CREATE/JOIN just get back a ROOM,<id>,<port> reply,
## and Global.go_to_game() hands off to the matching game scene, which
## connects to that port itself (same JOIN/WELCOME handshake Pong already
## used, just against a dynamic port now instead of a hardcoded one).

const NEON_CYAN := Color(0.1, 0.95, 1.0, 1.0)
const NEON_MAGENTA := Color(1.0, 0.2, 0.85, 1.0)
const BG_DARK := Color(0.05, 0.06, 0.09, 1.0)
const DIM_TEXT := Color(0.62, 0.72, 0.78, 1.0)

const LIST_RETRY_INTERVAL := 1.0
const LIST_MAX_ATTEMPTS := 10
const ROOMS_POLL_INTERVAL := 2.0

var udp := PacketPeerUDP.new()
var lobby_confirmed := false
var awaiting_list := false
var list_attempts := 0
var time_since_list_attempt := 0.0
var time_since_rooms_poll := 0.0
var pending_game := ""

var ip_input: LineEdit
var status_label: Label
var games_box: VBoxContainer
var rooms_box: VBoxContainer
var connect_btn: Button

func _ready() -> void:
	_build_ui()
	ip_input.text = Global.server_ip

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = BG_DARK
	bg.anchor_right = 1.0
	bg.anchor_bottom = 1.0
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	var scroll := ScrollContainer.new()
	scroll.anchor_left = 0.5
	scroll.anchor_right = 0.5
	scroll.anchor_top = 0.0
	scroll.anchor_bottom = 1.0
	scroll.offset_left = -230.0
	scroll.offset_right = 230.0
	scroll.offset_top = 16.0
	scroll.offset_bottom = -16.0
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)

	var vbox := VBoxContainer.new()
	vbox.custom_minimum_size = Vector2(460, 0)
	vbox.add_theme_constant_override("separation", 10)
	scroll.add_child(vbox)

	var title := Label.new()
	title.text = "ARCADE"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 34)
	title.add_theme_color_override("font_color", NEON_CYAN)
	vbox.add_child(title)

	var subtitle := Label.new()
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_color_override("font_color", DIM_TEXT)
	subtitle.add_theme_font_size_override("font_size", 13)
	vbox.add_child(subtitle)

	ip_input = LineEdit.new()
	ip_input.placeholder_text = "IP address"
	vbox.add_child(ip_input)

	connect_btn = Button.new()
	connect_btn.text = "Connect to Server"
	connect_btn.pressed.connect(_on_connect_pressed)
	vbox.add_child(connect_btn)

	status_label = Label.new()
	status_label.text = "Enter the IP address and connect."
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	vbox.add_child(status_label)

	vbox.add_child(HSeparator.new())

	var games_label := Label.new()
	games_label.text = "START A NEW GAME"
	games_label.add_theme_color_override("font_color", NEON_MAGENTA)
	games_label.add_theme_font_size_override("font_size", 16)
	vbox.add_child(games_label)

	games_box = VBoxContainer.new()
	games_box.add_theme_constant_override("separation", 6)
	vbox.add_child(games_box)

	vbox.add_child(HSeparator.new())

	var rooms_header := HBoxContainer.new()
	var rooms_label := Label.new()
	rooms_label.text = "JOIN AN ACTIVE ROOM"
	rooms_label.add_theme_color_override("font_color", NEON_MAGENTA)
	rooms_label.add_theme_font_size_override("font_size", 16)
	rooms_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rooms_header.add_child(rooms_label)
	var refresh_btn := Button.new()
	refresh_btn.text = "Refresh"
	refresh_btn.pressed.connect(_poll_rooms)
	rooms_header.add_child(refresh_btn)
	vbox.add_child(rooms_header)

	rooms_box = VBoxContainer.new()
	rooms_box.add_theme_constant_override("separation", 6)
	vbox.add_child(rooms_box)

	_render_no_rooms("Connect to a server to see active rooms.")

## ---------------------------------------------------------------- Connect

func _on_connect_pressed() -> void:
	var ip := ip_input.text.strip_edges()
	if ip.is_empty():
		status_label.text = "Enter the QNX server's IP address first."
		return
	Global.server_ip = ip
	udp.close()
	var err := udp.connect_to_host(ip, Global.lobby_port)
	if err != OK:
		status_label.text = "Could not open a socket to %s." % ip
		return
	lobby_confirmed = false
	awaiting_list = true
	list_attempts = 0
	time_since_list_attempt = 999.0
	status_label.text = "Reaching QNX lobby at %s:%d..." % [ip, Global.lobby_port]
	connect_btn.disabled = true
	_clear_box(games_box)
	_render_no_rooms("Connecting...")

func _try_list(delta: float) -> void:
	time_since_list_attempt += delta
	if time_since_list_attempt < LIST_RETRY_INTERVAL:
		return
	if list_attempts >= LIST_MAX_ATTEMPTS:
		status_label.text = "No response from the lobby."
		awaiting_list = false
		connect_btn.disabled = false
		return
	_send("LIST")
	list_attempts += 1
	time_since_list_attempt = 0.0

## ------------------------------------------------------------------ Loop

func _process(delta: float) -> void:
	if awaiting_list:
		_try_list(delta)

	while udp.get_available_packet_count() > 0:
		var bytes := udp.get_packet()
		var line := bytes.get_string_from_utf8().strip_edges()
		if line != "":
			_handle_line(line)

	if lobby_confirmed:
		time_since_rooms_poll += delta
		if time_since_rooms_poll >= ROOMS_POLL_INTERVAL:
			_poll_rooms()
			time_since_rooms_poll = 0.0

func _send(msg: String) -> void:
	udp.put_packet((msg + "\n").to_utf8_buffer())

func _poll_rooms() -> void:
	if lobby_confirmed:
		_send("ROOMS")

## --------------------------------------------------------------- Replies

func _handle_line(line: String) -> void:
	var parts := line.split(",")
	match parts[0]:
		"GAMES":
			lobby_confirmed = true
			awaiting_list = false
			connect_btn.disabled = false
			status_label.text = "Connected. Start a new game or join a room below."
			_render_games(parts.slice(1))
			_poll_rooms()
		"ROOMS":
			_render_rooms(parts.slice(1))
		"ROOM":
			var room_id := int(parts[1])
			var port := int(parts[2])
			status_label.text = "Joining %s room %d..." % [pending_game, room_id]
			Global.go_to_game(pending_game, room_id, port)
		"ERR":
			status_label.text = "Server said: %s" % parts[1]

## ----------------------------------------------------------- Build lists

func _clear_box(box: VBoxContainer) -> void:
	for child in box.get_children():
		child.queue_free()

func _render_games(names: Array) -> void:
	_clear_box(games_box)
	for raw_name in names:
		var name1: String = raw_name
		if name1.is_empty():
			continue
		var btn := Button.new()
		btn.text = "Create: %s" % Global.GAME_LABELS.get(name1, name1)
		btn.pressed.connect(_on_create_pressed.bind(name1))
		games_box.add_child(btn)

func _render_no_rooms(msg: String) -> void:
	_clear_box(rooms_box)
	var lbl := Label.new()
	lbl.text = msg
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl.autowrap_mode = TextServer.AUTOWRAP_WORD
	lbl.add_theme_color_override("font_color", DIM_TEXT)
	rooms_box.add_child(lbl)

func _render_rooms(entries: Array) -> void:
	var real_entries: Array = []
	for e in entries:
		if String(e) != "":
			real_entries.append(e)
	if real_entries.is_empty():
		_render_no_rooms("No active rooms yet. Create one above!")
		return
	_clear_box(rooms_box)
	for raw_entry in real_entries:
		var entry: String = raw_entry
		# format: <id>:<game>:<n>/<max>
		var main_parts := entry.split(":")
		if main_parts.size() < 3:
			continue
		var room_id := int(main_parts[0])
		var game: String = main_parts[1]
		var occ := main_parts[2] # "n/max"
		var occ_parts := occ.split("/")
		var n := int(occ_parts[0])
		var max_p := int(occ_parts[1]) if occ_parts.size() > 1 else 0

		var btn := Button.new()
		var label: String = Global.GAME_LABELS.get(game, game)
		btn.text = "Join Room %d -- %s (%d/%d)" % [room_id, label, n, max_p]
		if max_p > 0 and n >= max_p:
			btn.text += "  [FULL]"
			btn.disabled = true
		btn.pressed.connect(_on_join_pressed.bind(room_id, game))
		rooms_box.add_child(btn)

## ------------------------------------------------------------- Actions

func _on_create_pressed(game: String) -> void:
	pending_game = game
	status_label.text = "Creating a new %s room..." % Global.GAME_LABELS.get(game, game)
	_send("CREATE,%s" % game)

func _on_join_pressed(room_id: int, game: String) -> void:
	pending_game = game
	status_label.text = "Joining room %d..." % room_id
	_send("JOIN,%d" % room_id)
