extends Node
## Global.gd -- tiny autoload holding the handoff from Lobby.tscn to
## whichever game scene gets loaded next. The lobby fills these in right
## after a successful CREATE or JOIN reply from the lobby server; the game
## scene reads them in its own _ready() and connects straight to the match
## process, no re-typing the IP.

var server_ip: String = "172.31.98.45"
var lobby_port: int = 9000

var assigned_port: int = -1
var assigned_room_id: int = -1
var game_name: String = ""

## Path to load for each game name the lobby can hand out. One dictionary
## edit is all a new game scene needs to become reachable from the lobby.
const GAME_SCENES := {
	"pong": "res://scenes/Main.tscn",
	"tictactoe": "res://scenes/TicTacToe.tscn",
	"snake": "res://scenes/SnakeArena.tscn",
	"shooter": "res://scenes/ShooterArena.tscn",
	"trivia": "res://scenes/Trivia.tscn",
}

## Friendly display names for the lobby's game-picker buttons.
const GAME_LABELS := {
	"pong": "Pong (2p)",
	"tictactoe": "Tic-Tac-Toe (2p)",
	"snake": "Snake Arena (2-4p)",
	"shooter": "Shooter (2-4p)",
	"trivia": "Buzzer Trivia (2-4p)",
}

func go_to_game(game: String, room_id: int, port: int) -> void:
	game_name = game
	assigned_room_id = room_id
	assigned_port = port
	var scene_path: String = GAME_SCENES.get(game, "")
	if scene_path == "":
		push_error("no scene registered for game '%s'" % game)
		return
	get_tree().change_scene_to_file(scene_path)

func return_to_lobby() -> void:
	assigned_port = -1
	assigned_room_id = -1
	game_name = ""
	get_tree().change_scene_to_file("res://scenes/Lobby.tscn")
