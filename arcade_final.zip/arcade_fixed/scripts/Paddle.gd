extends Node2D
## Paddle.gd
##
## Two modes, chosen per-instance by Main.gd via `is_predicted`:
##
##   - Opponent paddle (is_predicted = false): pure display node, exactly
##     as before -- glides toward whatever y the server last broadcast
##     (set_target_y). You can't predict someone else's input, so there's
##     nothing to do here but wait for the server and smooth it visually.
##
##   - YOUR OWN paddle (is_predicted = true): moves IMMEDIATELY on local
##     input via predict_move(), before any round trip to the server has
##     happened. This is what removes the network round-trip from your
##     own paddle's felt response time -- you see it move the instant you
##     press a key, not ~1 round-trip later. When the next STATE broadcast
##     arrives with the server's authoritative position for your seat,
##     reconcile() gently blends back toward that truth (rather than
##     snapping), so small prediction/server disagreement from packet
##     jitter doesn't cause a visible pop.

@export_enum("left", "right") var control_side: String = "left"
@export var half_height: float = 55.0

var is_predicted: bool = false
var target_y: float = 300.0
var glow_pulse: float = 0.0

const COLOR_LEFT := Color(0.0, 0.96, 1.0)   # cyan -- Player 1 (seat 0)
const COLOR_RIGHT := Color(1.0, 0.18, 0.82) # magenta -- Player 2 (seat 1)
const LERP_SPEED := 18.0
const PREDICT_SPEED := 420.0       # MUST match PADDLE_SPEED in the server's qnx_game_.c
const RECONCILE_STRENGTH := 10.0   # how fast we blend back to server truth each STATE update

func set_target_y(y: float) -> void:
	target_y = y

func predict_move(dir: float, delta: float) -> void:
	position.y += dir * PREDICT_SPEED * delta
	position.y = clamp(position.y, half_height + 20, 600 - half_height - 20)
	target_y = position.y

func reconcile(server_y: float, delta: float) -> void:
	# A soft blend, not a hard snap: on a good connection this is nearly
	# invisible, and on a laggy one it still corrects within a few frames
	# instead of jarring the player with a sudden jump every STATE packet.
	position.y = lerp(position.y, server_y, clamp(delta * RECONCILE_STRENGTH, 0.0, 1.0))
	target_y = position.y

func _process(delta: float) -> void:
	if not is_predicted:
		position.y = lerp(position.y, target_y, clamp(delta * LERP_SPEED, 0.0, 1.0))
	glow_pulse = fmod(glow_pulse + delta * 3.0, TAU)
	queue_redraw()

func _draw() -> void:
	var col := COLOR_LEFT if control_side == "left" else COLOR_RIGHT
	var w := 16.0
	var h := half_height * 2.0
	var rect := Rect2(-w / 2.0, -h / 2.0, w, h)
	var glow := 0.5 + 0.5 * sin(glow_pulse)
	# Cheap fake bloom: a stack of soft, oversized, low-alpha copies.
	for i in range(4, 0, -1):
		var pad := float(i) * 4.0
		var a := (0.06 + 0.05 * glow) / float(i)
		draw_rect(rect.grow(pad), Color(col.r, col.g, col.b, a), true)
	draw_rect(rect, col, true)
