extends Node2D
## ShooterArena.gd -- thin client for the shooter GameModule. The server
## owns all movement, bullet travel, and hit detection -- this client only
## reports intent (move dir, aim angle, firing) and renders whatever STATE
## comes back. It never decides "I hit someone" locally.

const JOIN_RETRY_INTERVAL := 1.0
const JOIN_MAX_ATTEMPTS := 10
const INPUT_SEND_INTERVAL := 1.0 / 30.0
const PING_INTERVAL := 1.0
const PLAYER_COLORS := [
	Color(0.1, 0.95, 1.0, 1.0),
	Color(1.0, 0.2, 0.85, 1.0),
	Color(1.0, 0.85, 0.1, 1.0),
	Color(0.3, 1.0, 0.4, 1.0),
]

var udp := PacketPeerUDP.new()
var seat: int = -1
var awaiting_welcome := false
var join_attempts := 0
var time_since_join_attempt := 0.0
var time_since_input_sent := 0.0

# Real RTT ping -- see SnakeArena.gd/Trivia.gd for the same pattern.
var ping_ms: float = -1.0
var ping_awaiting := false
var ping_sent_at_msec: int = 0
var time_since_ping := 999.0

# players[i] = {connected, x, y, angle, alive, kills}
var players: Array = []
var bullets: Array = [] # [{x,y}, ...]
var result_text := ""
var firing_held := false

var status_label: Label
var seat_label: Label
var kills_label: Label
var ping_label: Label

func _ready() -> void:
	for i in range(4):
		players.append({"connected": 0, "x": 0.0, "y": 0.0, "angle": 0.0, "alive": 0, "kills": 0})
	_build_ui()
	awaiting_welcome = true
	join_attempts = 0
	time_since_join_attempt = 999.0
	var err := udp.connect_to_host(Global.server_ip, Global.assigned_port)
	if err != OK:
		status_label.text = "Could not open socket to room."

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)

	var back_btn := Button.new()
	back_btn.text = "< Lobby"
	back_btn.position = Vector2(24, 16)
	back_btn.pressed.connect(func(): Global.return_to_lobby())
	layer.add_child(back_btn)

	var title := Label.new()
	title.text = "SHOOTER -- Room %d" % Global.assigned_room_id
	title.position = Vector2(300, 16)
	title.add_theme_font_size_override("font_size", 20)
	title.add_theme_color_override("font_color", Color(1.0, 0.85, 0.1))
	layer.add_child(title)

	seat_label = Label.new()
	seat_label.position = Vector2(24, 44)
	layer.add_child(seat_label)

	kills_label = Label.new()
	kills_label.position = Vector2(24, 560)
	layer.add_child(kills_label)

	ping_label = Label.new()
	ping_label.position = Vector2(660, 16)
	ping_label.add_theme_font_size_override("font_size", 12)
	ping_label.add_theme_color_override("font_color", Color(0.6, 1.0, 0.85, 0.95))
	layer.add_child(ping_label)

	status_label = Label.new()
	status_label.position = Vector2(450, 560)
	status_label.add_theme_color_override("font_color", Color(1.0, 0.2, 0.85))
	layer.add_child(status_label)

	var hint := Label.new()
	hint.text = "WASD move -- mouse aim -- click or Space to fire -- first to 5 kills wins"
	hint.position = Vector2(220, 44)
	hint.add_theme_font_size_override("font_size", 12)
	layer.add_child(hint)

func _process(delta: float) -> void:
	if awaiting_welcome:
		_try_join(delta)

	while udp.get_available_packet_count() > 0:
		var line := udp.get_packet().get_string_from_utf8().strip_edges()
		if line != "":
			_handle_line(line)

	if seat >= 0:
		var me: Dictionary = players[seat]
		seat_label.text = "You are player #%d (%s)" % [seat, "alive" if me["alive"] == 1 else "respawning..."]
		var kt := "Kills  "
		for i in range(4):
			kt += "P%d:%d  " % [i, players[i]["kills"]]
		kills_label.text = kt
		_send_input(delta)
		_send_ping(delta)

	ping_label.text = ("ping: %.0fms" % ping_ms) if ping_ms >= 0.0 else "ping: --"

	queue_redraw()

func _try_join(delta: float) -> void:
	time_since_join_attempt += delta
	if time_since_join_attempt < JOIN_RETRY_INTERVAL:
		return
	if join_attempts >= JOIN_MAX_ATTEMPTS:
		status_label.text = "No response from the room."
		awaiting_welcome = false
		return
	udp.put_packet("JOIN\n".to_utf8_buffer())
	join_attempts += 1
	time_since_join_attempt = 0.0

func _send_ping(delta: float) -> void:
	time_since_ping += delta
	if time_since_ping < PING_INTERVAL:
		return
	time_since_ping = 0.0
	ping_sent_at_msec = Time.get_ticks_msec()
	ping_awaiting = true
	udp.put_packet(("PING,%d\n" % seat).to_utf8_buffer())

func _handle_line(line: String) -> void:
	var parts := line.split(",")
	match parts[0]:
		"PONG":
			if ping_awaiting:
				ping_ms = float(Time.get_ticks_msec() - ping_sent_at_msec)
				ping_awaiting = false
		"WELCOME":
			seat = int(parts[1])
			awaiting_welcome = false
			status_label.text = ""
		"FULL":
			awaiting_welcome = false
			status_label.text = "Room is full."
		"STATE":
			_apply_state(parts)
		"FRAG":
			pass # kill feed omitted for simplicity; kills counter covers it
		"WIN":
			result_text = "PLAYER %s WINS THE MATCH!" % parts[1]
		"OPPONENT_LEFT":
			status_label.text = "A player left."

func _apply_state(parts: PackedStringArray) -> void:
	if parts.size() < 3:
		return
	var player_entries: PackedStringArray = parts[1].split(";")
	var count := 0
	for entry in player_entries:
		if entry == "" or count >= 4:
			continue
		var f := entry.split(":")
		if f.size() != 6:
			continue
		players[count] = {
			"connected": int(f[0]), "x": float(f[1]), "y": float(f[2]),
			"angle": float(f[3]), "alive": int(f[4]), "kills": int(f[5]),
		}
		count += 1

	bullets.clear()
	var bullet_entries: PackedStringArray = parts[2].split(";")
	for entry in bullet_entries:
		if entry == "":
			continue
		var f := entry.split(":")
		if f.size() == 2:
			bullets.append({"x": float(f[0]), "y": float(f[1])})

func _send_input(delta: float) -> void:
	time_since_input_sent += delta
	if time_since_input_sent < INPUT_SEND_INTERVAL:
		return
	time_since_input_sent = 0.0

	var dx := 0.0
	var dy := 0.0
	if Input.is_physical_key_pressed(KEY_D):
		dx += 1.0
	if Input.is_physical_key_pressed(KEY_A):
		dx -= 1.0
	if Input.is_physical_key_pressed(KEY_S):
		dy += 1.0
	if Input.is_physical_key_pressed(KEY_W):
		dy -= 1.0

	var me: Dictionary = players[seat]
	var my_pos := Vector2(me["x"], me["y"])
	var angle := (get_viewport().get_mouse_position() - my_pos).angle()

	var firing := 1 if (firing_held or Input.is_physical_key_pressed(KEY_SPACE)) else 0
	udp.put_packet(("IN,%d,%.2f,%.2f,%.3f,%d\n" % [seat, dx, dy, angle, firing]).to_utf8_buffer())

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		firing_held = event.pressed

func _draw() -> void:
	draw_rect(Rect2(0, 0, 800, 600), Color(0.05, 0.06, 0.09, 1.0))
	draw_rect(Rect2(4, 4, 792, 592), Color(0.3, 0.35, 0.4, 0.6), false, 2.0)

	for b in bullets:
		draw_circle(Vector2(b["x"], b["y"]), 4.0, Color(1.0, 1.0, 1.0, 0.9))

	for i in range(4):
		var p: Dictionary = players[i]
		if p["connected"] != 1 or p["alive"] != 1:
			continue
		var pos := Vector2(p["x"], p["y"])
		var color: Color = PLAYER_COLORS[i]
		draw_circle(pos, 16.0, color)
		var aim := Vector2(cos(p["angle"]), sin(p["angle"])) * 22.0
		draw_line(pos, pos + aim, Color.WHITE, 3.0)
		draw_string(ThemeDB.fallback_font, pos + Vector2(-8, -22), "P%d" % i, HORIZONTAL_ALIGNMENT_LEFT, -1, 12)

	if result_text != "":
		draw_string(ThemeDB.fallback_font, Vector2(200, 300), result_text, HORIZONTAL_ALIGNMENT_CENTER, -1, 26)
