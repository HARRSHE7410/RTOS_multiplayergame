extends Node2D
## Main.gd -- QNX Neon Pong (client)
##
## All AUTHORITATIVE game state -- ball position, both paddle positions,
## score, round countdown -- lives on the native C server (qnx_game_.c) on
## the QNX box. This client does four things: (1) predicts its own paddle
## locally so input feels instant rather than waiting a round trip, (2)
## reconciles that prediction against the server's authoritative position
## on each STATE update, (3) sends PING,<seat> once a second and times how
## long PONG takes to come back for a real round-trip latency reading (the
## generic match-process keepalive already answers this -- see
## protocol.h), and (4) reads the JITTER broadcast the server sends every
## ~5s and shows all of it in a small on-screen debug readout, in addition
## to the server's own console/slog2info output.

const JOIN_RETRY_INTERVAL := 1.0
const JOIN_MAX_ATTEMPTS := 10
const INPUT_SEND_INTERVAL := 1.0 / 30.0
const PING_INTERVAL := 1.0

var udp := PacketPeerUDP.new()
var seat: int = -1
var awaiting_welcome := false
var join_attempts := 0
var time_since_join_attempt := 0.0
var time_since_input_sent := 0.0

var last_ball_pos: Vector2 = Vector2(400, 300)
var prev_ball_delta: Vector2 = Vector2.ZERO
var last_score := [0, 0]
var own_dir: float = 0.0
var time_since_last_packet: float = 0.0
const SERVER_STALL_TIMEOUT := 2.0 # if we hear nothing this long while "connected", assume the server respawned

var own_latency_ms: float = -1.0
var ping_awaiting := false
var ping_sent_at_msec: int = 0
var time_since_ping := 999.0
var server_jitter_ms: float = -1.0

@onready var left_paddle := $LeftPaddle
@onready var right_paddle := $RightPaddle
@onready var ball := $Ball
@onready var bounce_sfx: AudioStreamPlayer = $BounceSFX
@onready var score_sfx: AudioStreamPlayer = $ScoreSFX

@onready var menu_panel: Control = $UI/MenuPanel
@onready var ip_input: LineEdit = $UI/MenuPanel/VBox/IPInput
@onready var status_label: Label = $UI/MenuPanel/VBox/StatusLabel
@onready var join_button: Button = $UI/MenuPanel/VBox/JoinButton

@onready var hud: Control = $UI/HUD
@onready var left_score_label: Label = $UI/HUD/LeftScoreLabel
@onready var right_score_label: Label = $UI/HUD/RightScoreLabel
@onready var countdown_label: Label = $UI/HUD/CountdownLabel

var debug_label: Label

func _ready() -> void:
	hud.hide()
	join_button.pressed.connect(_on_connect_pressed)
	ip_input.text = Global.server_ip
	_build_debug_overlay()
	_build_back_button()
	if Global.assigned_port > 0:
		# The lobby already created/found this room for us -- skip straight
		# to joining its match port instead of making the player retype
		# anything or click Connect again.
		status_label.text = "Room ready. Joining Pong..."
		_on_connect_pressed()

func _build_back_button() -> void:
	var back_btn := Button.new()
	back_btn.text = "< Lobby"
	back_btn.position = Vector2(690, 4)
	back_btn.pressed.connect(func(): Global.return_to_lobby())
	add_child(back_btn)

func _build_debug_overlay() -> void:
	# Built here in code rather than in the .tscn, so this works without
	# any scene editing -- just drop this script in. Sits above the
	# arena's top border (border drawn at y=20, see _draw() below).
	debug_label = Label.new()
	debug_label.position = Vector2(24, 0)
	debug_label.add_theme_font_size_override("font_size", 12)
	debug_label.add_theme_color_override("font_color", Color(0.6, 1.0, 0.85, 0.95))
	debug_label.text = ""
	add_child(debug_label)

func _refresh_debug_overlay() -> void:
	var own_txt := "%.0fms" % own_latency_ms if own_latency_ms >= 0.0 else "--"
	var jitter_txt := "%.2fms" % server_jitter_ms if server_jitter_ms >= 0.0 else "--"
	var fps_txt := str(Engine.get_frames_per_second())
	debug_label.text = "fps: %s   ping: %s   server tick jitter: %s" % [fps_txt, own_txt, jitter_txt]

func _draw() -> void:
	draw_rect(Rect2(20, 20, 760, 560), Color(0.0, 0.85, 1.0, 0.9), false, 3.0)
	var y := 20.0
	while y < 580.0:
		draw_line(Vector2(400, y), Vector2(400, y + 14), Color(1, 1, 1, 0.25), 3.0)
		y += 26.0

## ---------------------------------------------------------------- Connect

func _on_connect_pressed() -> void:
	var ip: String = ip_input.text.strip_edges()
	if ip.is_empty():
		status_label.text = "Enter the QNX server's IP address first."
		return
	var port: int = Global.assigned_port if Global.assigned_port > 0 else 8080
	var err := udp.connect_to_host(ip, port)
	if err != OK:
		status_label.text = "Could not open a socket to %s:%d." % [ip, port]
		return
	seat = -1
	awaiting_welcome = true
	join_attempts = 0
	time_since_join_attempt = 999.0 # send the first JOIN immediately
	status_label.text = "Reaching QNX server at %s..." % ip
	join_button.disabled = true

func _try_join(delta: float) -> void:
	time_since_join_attempt += delta
	if time_since_join_attempt < JOIN_RETRY_INTERVAL:
		return
	if join_attempts >= JOIN_MAX_ATTEMPTS:
		status_label.text = "No response from the server. Check the IP and that qnx_game_ is running on the Pi."
		awaiting_welcome = false
		join_button.disabled = false
		return
	udp.put_packet("JOIN\n".to_utf8_buffer())
	join_attempts += 1
	time_since_join_attempt = 0.0

func _send_ping(delta: float) -> void:
	time_since_ping += delta
	if time_since_ping < PING_INTERVAL:
		return
	time_since_ping = 0.0
	ping_sent_at_msec = Time.get_ticks_msec()
	ping_awaiting = true
	udp.put_packet(("PING,%d\n" % seat).to_utf8_buffer())

## ------------------------------------------------------------------ Loop

func _process(delta: float) -> void:
	if awaiting_welcome:
		_try_join(delta)

	while udp.get_available_packet_count() > 0:
		var bytes := udp.get_packet()
		var line := bytes.get_string_from_utf8().strip_edges()
		if line != "":
			_handle_line(line, delta)
			time_since_last_packet = 0.0

	# If we think we're connected (seat != -1) but haven't heard ANYTHING
	# from the server in a while, the most likely explanation is that the
	# server process died and got respawned (e.g. by qnx_watchdog after a
	# crash) -- the new process has no idea we exist until we JOIN again.
	# Auto-rejoin here so the demo is hands-off: kill -9 the server, and
	# the client silently reconnects on its own once it's back, instead
	# of sitting there frozen until someone manually clicks Connect.
	if seat != -1:
		time_since_last_packet += delta
		if time_since_last_packet > SERVER_STALL_TIMEOUT:
			menu_panel.show()
			status_label.text = "Lost contact with the server -- reconnecting..."
			seat = -1
			left_paddle.is_predicted = false
			right_paddle.is_predicted = false
			awaiting_welcome = true
			join_attempts = 0
			time_since_join_attempt = 999.0
			time_since_last_packet = 0.0

	_refresh_debug_overlay() # FPS changes every frame, unlike ping/jitter

	if seat != -1:
		own_dir = _read_dir()
		if seat == 0:
			left_paddle.predict_move(own_dir, delta)
		elif seat == 1:
			right_paddle.predict_move(own_dir, delta)
		_send_input(delta)
		_send_ping(delta)

func _read_dir() -> float:
	var dir := 0.0
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
		dir += 1.0
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
		dir -= 1.0
	return dir

func _handle_line(line: String, delta: float) -> void:
	var parts := line.split(",")
	match parts[0]:
		"WELCOME":
			seat = int(parts[1])
			awaiting_welcome = false
			menu_panel.hide()
			hud.show()
			status_label.text = ""
			if seat == 0:
				left_paddle.is_predicted = true
			elif seat == 1:
				right_paddle.is_predicted = true
		"FULL":
			awaiting_welcome = false
			join_button.disabled = false
			status_label.text = "Server already has two players. Try again shortly."
		"STATE":
			_apply_state(parts, delta)
		"COUNTDOWN":
			countdown_label.text = parts[1]
		"GO":
			countdown_label.text = "GO!"
		"WIN":
			var winner_seat := int(parts[1])
			var winner_name := "PLAYER 1 (CYAN)" if winner_seat == 0 else "PLAYER 2 (MAGENTA)"
			countdown_label.text = "%s WINS!" % winner_name
		"OPPONENT_LEFT":
			hud.hide()
			menu_panel.show()
			join_button.disabled = false
			status_label.text = "Opponent disconnected. Click Connect to rejoin."
			seat = -1
			left_paddle.is_predicted = false
			right_paddle.is_predicted = false
			own_latency_ms = -1.0
		"PONG":
			if ping_awaiting:
				own_latency_ms = float(Time.get_ticks_msec() - ping_sent_at_msec)
				ping_awaiting = false
		"JITTER":
			server_jitter_ms = float(parts[1])
			_refresh_debug_overlay()

func _apply_state(parts: PackedStringArray, delta: float) -> void:
	var bx := float(parts[1])
	var by := float(parts[2])
	var p0y := float(parts[3])
	var p1y := float(parts[4])
	var s0 := int(parts[5])
	var s1 := int(parts[6])

	var new_ball_pos := Vector2(bx, by)
	var delta_move := new_ball_pos - last_ball_pos
	if delta_move.length() < 60.0 and prev_ball_delta.length() < 60.0 and prev_ball_delta.length() > 0.5:
		if abs(prev_ball_delta.x) > 0.5 and sign(delta_move.x) != sign(prev_ball_delta.x):
			_play_bounce_sfx()
		elif abs(prev_ball_delta.y) > 0.5 and sign(delta_move.y) != sign(prev_ball_delta.y):
			_play_bounce_sfx()
	prev_ball_delta = delta_move
	last_ball_pos = new_ball_pos

	ball.set_target_position(new_ball_pos)

	if seat == 0:
		left_paddle.reconcile(p0y, delta)
		right_paddle.set_target_y(p1y)
	elif seat == 1:
		right_paddle.reconcile(p1y, delta)
		left_paddle.set_target_y(p0y)
	else:
		left_paddle.set_target_y(p0y)
		right_paddle.set_target_y(p1y)

	if s0 != last_score[0] or s1 != last_score[1]:
		_play_score_sfx()
		last_score = [s0, s1]

	left_score_label.text = str(s0)
	right_score_label.text = str(s1)

func _send_input(delta: float) -> void:
	time_since_input_sent += delta
	if time_since_input_sent < INPUT_SEND_INTERVAL:
		return
	time_since_input_sent = 0.0
	udp.put_packet(("IN,%d,%.2f\n" % [seat, own_dir]).to_utf8_buffer())

## --------------------------------------------------------- Procedural audio

func _play_bounce_sfx() -> void:
	_play_tone(bounce_sfx, 420.0, 0.05)

func _play_score_sfx() -> void:
	_play_tone(score_sfx, 180.0, 0.25)

func _play_tone(player: AudioStreamPlayer, freq: float, duration: float) -> void:
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = 22050
	gen.buffer_length = duration + 0.05
	player.stream = gen
	player.play()
	var playback: AudioStreamGeneratorPlayback = player.get_stream_playback()
	var sample_count := int(gen.mix_rate * duration)
	for i in range(sample_count):
		var t := float(i) / gen.mix_rate
		var envelope := 1.0 - (float(i) / sample_count)
		var sample: float = sign(sin(TAU * freq * t)) * 0.25 * envelope
		playback.push_frame(Vector2(sample, sample))
