extends Node2D
## Ball.gd
##
## Pure display node. The native QNX server computes every bounce and every
## collision; this script only glides toward the last position it was told
## (via set_target_position) and draws the glow + motion trail.

@export var radius: float = 9.0

var target_pos: Vector2 = Vector2(400, 300)
var trail: Array = []
const TRAIL_LEN := 10
const LERP_SPEED := 20.0

func set_target_position(pos: Vector2) -> void:
	target_pos = pos

func snap_to(pos: Vector2) -> void:
	position = pos
	target_pos = pos
	trail.clear()

func _process(delta: float) -> void:
	position = position.lerp(target_pos, clamp(delta * LERP_SPEED, 0.0, 1.0))
	trail.push_front(position)
	if trail.size() > TRAIL_LEN:
		trail.pop_back()
	queue_redraw()

func _draw() -> void:
	for i in range(trail.size()):
		var t := 1.0 - float(i) / float(TRAIL_LEN)
		var local: Vector2 = trail[i] - position
		draw_circle(local, radius * t, Color(1.0, 1.0, 0.2, t * 0.35))
	for i in range(3, 0, -1):
		draw_circle(Vector2.ZERO, radius + float(i) * 3.0, Color(1.0, 1.0, 0.2, 0.05))
	draw_circle(Vector2.ZERO, radius, Color(1.0, 0.98, 0.25))
