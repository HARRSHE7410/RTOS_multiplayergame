extends Node2D
## SnakeArena.gd -- thin client for the snake GameModule. The server owns
## the entire grid, every snake's body, and collision rules; this only
## renders the grid it's sent and forwards direction changes.

const JOIN_RETRY_INTERVAL := 1.0
const JOIN_MAX_ATTEMPTS := 10
const GRID_ORIGIN := Vector2(80, 80)
const CELL_PX := 28.0

const SNAKE_COLORS := [
	Color(0.1, 0.95, 1.0, 1.0),   # seat 0 cyan
	Color(1.0, 0.2, 0.85, 1.0),  # seat 1 magenta
	Color(1.0, 0.85, 0.1, 1.0),  # seat 2 yellow
	Color(0.3, 1.0, 0.4, 1.0),   # seat 3 green
]

const PING_INTERVAL := 1.0

var udp := PacketPeerUDP.new()
var seat: int = -1
var awaiting_welcome := false
var join_attempts := 0
var time_since_join_attempt := 0.0

# Real RTT ping: we send PING,<seat> and time how long PONG takes to come
# back. The server has always supported PING,<seat> -> PONG as a generic
# keepalive (see protocol.h); this arena just never rode it for a display
# before, so ping sat frozen at "--"/0 no matter what was happening.
var ping_ms: float = -1.0
var ping_awaiting := false
var ping_sent_at_msec: int = 0
var time_since_ping := 999.0

var grid_w := 24
var grid_h := 18
var grid_str := ""
var scores: Array = [0, 0, 0, 0]
var alive_flags: Array = [0, 0, 0, 0]
var last_sent_dir := -1
var result_text := ""

var status_label: Label
var seat_label: Label
var scores_label: Label
var ping_label: Label

func _ready() -> void:
	_build_ui()
	awaiting_welcome = true
	join_attempts = 0
	time_since_join_attempt = 999.0
	var err := udp.connect_to_host(Global.server_ip, Global.assigned_port)
	if err != OK:
		status_label.text = "Could not open socket to room."

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)

	var back_btn := Button.new()
	back_btn.text = "< Lobby"
	back_btn.position = Vector2(24, 16)
	back_btn.pressed.connect(func(): Global.return_to_lobby())
	layer.add_child(back_btn)

	var title := Label.new()
	title.text = "SNAKE ARENA -- Room %d" % Global.assigned_room_id
	title.position = Vector2(260, 16)
	title.add_theme_font_size_override("font_size", 20)
	title.add_theme_color_override("font_color", Color(0.3, 1.0, 0.4))
	layer.add_child(title)

	seat_label = Label.new()
	seat_label.position = Vector2(24, 44)
	layer.add_child(seat_label)

	scores_label = Label.new()
	scores_label.position = Vector2(24, 560)
	layer.add_child(scores_label)

	status_label = Label.new()
	status_label.position = Vector2(400, 560)
	status_label.add_theme_color_override("font_color", Color(1.0, 0.2, 0.85))
	layer.add_child(status_label)

	ping_label = Label.new()
	ping_label.position = Vector2(660, 16)
	ping_label.add_theme_font_size_override("font_size", 12)
	ping_label.add_theme_color_override("font_color", Color(0.6, 1.0, 0.85, 0.95))
	layer.add_child(ping_label)

func _process(delta: float) -> void:
	if awaiting_welcome:
		_try_join(delta)

	while udp.get_available_packet_count() > 0:
		var line := udp.get_packet().get_string_from_utf8().strip_edges()
		if line != "":
			_handle_line(line)

	if seat >= 0:
		seat_label.text = "You are snake #%d (%s)" % [seat, "alive" if (seat < alive_flags.size() and alive_flags[seat] == 1) else "eliminated"]
		_send_direction()
		_send_ping(delta)

	ping_label.text = ("ping: %.0fms" % ping_ms) if ping_ms >= 0.0 else "ping: --"

	var score_txt := "Scores  "
	for i in range(4):
		score_txt += "P%d:%d  " % [i, scores[i]]
	scores_label.text = score_txt

	queue_redraw()

func _try_join(delta: float) -> void:
	time_since_join_attempt += delta
	if time_since_join_attempt < JOIN_RETRY_INTERVAL:
		return
	if join_attempts >= JOIN_MAX_ATTEMPTS:
		status_label.text = "No response from the room."
		awaiting_welcome = false
		return
	udp.put_packet("JOIN\n".to_utf8_buffer())
	join_attempts += 1
	time_since_join_attempt = 0.0

func _send_ping(delta: float) -> void:
	time_since_ping += delta
	if time_since_ping < PING_INTERVAL:
		return
	time_since_ping = 0.0
	ping_sent_at_msec = Time.get_ticks_msec()
	ping_awaiting = true
	udp.put_packet(("PING,%d\n" % seat).to_utf8_buffer())

func _handle_line(line: String) -> void:
	var parts := line.split(",")
	match parts[0]:
		"PONG":
			if ping_awaiting:
				ping_ms = float(Time.get_ticks_msec() - ping_sent_at_msec)
				ping_awaiting = false
		"WELCOME":
			seat = int(parts[1])
			awaiting_welcome = false
			status_label.text = ""
		"FULL":
			awaiting_welcome = false
			status_label.text = "Room is full."
		"STATE":
			grid_w = int(parts[1])
			grid_h = int(parts[2])
			grid_str = parts[3]
			var score_parts: PackedStringArray = parts[4].split(",") if parts.size() > 4 else []
			for i in range(4):
				if i < score_parts.size():
					var pair := score_parts[i].split(":")
					if pair.size() == 2:
						alive_flags[i] = int(pair[0])
						scores[i] = int(pair[1])
		"WIN":
			result_text = "SNAKE #%s WINS!" % parts[1]
		"DRAW":
			result_text = "DRAW -- everyone crashed!"
		"OPPONENT_LEFT":
			status_label.text = "A player left."

func _send_direction() -> void:
	var dir := last_sent_dir
	if Input.is_physical_key_pressed(KEY_UP) or Input.is_physical_key_pressed(KEY_W):
		dir = 0
	elif Input.is_physical_key_pressed(KEY_DOWN) or Input.is_physical_key_pressed(KEY_S):
		dir = 1
	elif Input.is_physical_key_pressed(KEY_LEFT) or Input.is_physical_key_pressed(KEY_A):
		dir = 2
	elif Input.is_physical_key_pressed(KEY_RIGHT) or Input.is_physical_key_pressed(KEY_D):
		dir = 3
	if dir != last_sent_dir and dir >= 0:
		last_sent_dir = dir
		udp.put_packet(("IN,%d,%d\n" % [seat, dir]).to_utf8_buffer())

func _draw() -> void:
	draw_rect(Rect2(GRID_ORIGIN, Vector2(grid_w * CELL_PX, grid_h * CELL_PX)), Color(0.06, 0.07, 0.10, 1.0))
	if grid_str.length() != grid_w * grid_h:
		return
	for y in range(grid_h):
		for x in range(grid_w):
			var c := grid_str[y * grid_w + x]
			if c == ".":
				continue
			var pos := GRID_ORIGIN + Vector2(x * CELL_PX, y * CELL_PX)
			if c == "F":
				draw_circle(pos + Vector2(CELL_PX, CELL_PX) * 0.5, CELL_PX * 0.32, Color(1.0, 0.85, 0.1))
			else:
				var idx := c.to_int()
				var color: Color = SNAKE_COLORS[idx] if idx >= 0 and idx < 4 else Color.WHITE
				draw_rect(Rect2(pos + Vector2(2, 2), Vector2(CELL_PX - 4, CELL_PX - 4)), color)

	if result_text != "":
		draw_string(ThemeDB.fallback_font, Vector2(260, 60), result_text, HORIZONTAL_ALIGNMENT_CENTER, -1, 22)
