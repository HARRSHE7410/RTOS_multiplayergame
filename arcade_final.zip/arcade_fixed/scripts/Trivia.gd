extends Node2D
## Trivia.gd -- thin client for the trivia GameModule. The server is the
## sole judge of "correct, and who answered first" -- this only displays
## the current question and forwards a chosen option index.

const JOIN_RETRY_INTERVAL := 1.0
const JOIN_MAX_ATTEMPTS := 10
const PING_INTERVAL := 1.0
const NEON_CYAN := Color(0.1, 0.95, 1.0, 1.0)
const NEON_MAGENTA := Color(1.0, 0.2, 0.85, 1.0)

var udp := PacketPeerUDP.new()
var seat: int = -1
var awaiting_welcome := false
var join_attempts := 0
var time_since_join_attempt := 0.0

# Real RTT ping (same PING,<seat> -> PONG keepalive every other arena
# uses -- see protocol.h). Trivia's idle_ok match process blocks on
# recvfrom() between events rather than polling, but it still answers
# PING immediately, so this works exactly the same as the busier games.
var ping_ms: float = -1.0
var ping_awaiting := false
var ping_sent_at_msec: int = 0
var time_since_ping := 999.0

var question_text := "Waiting for enough players..."
var options: Array = ["", "", "", ""]
var phase := 0 # 0 waiting, 1 asking, 2 reveal
var seconds_left := 0
var scores: Array = [0, 0, 0, 0]
var correct_idx := -1
var locked_out := false
var last_result_text := ""

var status_label: Label
var seat_label: Label
var question_label: Label
var timer_label: Label
var scores_label: Label
var ping_label: Label
var option_buttons: Array = []

func _ready() -> void:
	_build_ui()
	if Global.assigned_port <= 0:
		status_label.text = "No room assigned."
		return
	awaiting_welcome = true
	join_attempts = 0
	time_since_join_attempt = 999.0
	var err := udp.connect_to_host(Global.server_ip, Global.assigned_port)
	if err != OK:
		status_label.text = "Could not open socket to room."

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)

	var back_btn := Button.new()
	back_btn.text = "< Lobby"
	back_btn.position = Vector2(24, 16)
	back_btn.pressed.connect(func(): Global.return_to_lobby())
	layer.add_child(back_btn)

	var title := Label.new()
	title.text = "BUZZER TRIVIA -- Room %d" % Global.assigned_room_id
	title.position = Vector2(260, 16)
	title.add_theme_font_size_override("font_size", 20)
	title.add_theme_color_override("font_color", NEON_CYAN)
	layer.add_child(title)

	seat_label = Label.new()
	seat_label.position = Vector2(24, 50)
	layer.add_child(seat_label)

	ping_label = Label.new()
	ping_label.position = Vector2(660, 16)
	ping_label.add_theme_font_size_override("font_size", 12)
	ping_label.add_theme_color_override("font_color", Color(0.6, 1.0, 0.85, 0.95))
	layer.add_child(ping_label)

	timer_label = Label.new()
	timer_label.position = Vector2(700, 50)
	timer_label.add_theme_color_override("font_color", NEON_MAGENTA)
	layer.add_child(timer_label)

	question_label = Label.new()
	question_label.position = Vector2(80, 140)
	question_label.custom_minimum_size = Vector2(640, 80)
	question_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	question_label.add_theme_font_size_override("font_size", 22)
	question_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	layer.add_child(question_label)

	for i in range(4):
		var btn := Button.new()
		btn.custom_minimum_size = Vector2(300, 60)
		var col := i % 2
		var row := i / 2
		btn.position = Vector2(120 + col * 340, 260 + row * 90)
		btn.pressed.connect(_on_option_pressed.bind(i))
		layer.add_child(btn)
		option_buttons.append(btn)

	scores_label = Label.new()
	scores_label.position = Vector2(24, 560)
	layer.add_child(scores_label)

	status_label = Label.new()
	status_label.position = Vector2(450, 560)
	status_label.add_theme_color_override("font_color", NEON_MAGENTA)
	layer.add_child(status_label)

func _process(delta: float) -> void:
	if awaiting_welcome:
		_try_join(delta)

	while udp.get_available_packet_count() > 0:
		var line := udp.get_packet().get_string_from_utf8().strip_edges()
		if line != "":
			_handle_line(line)

	if seat >= 0:
		seat_label.text = "You are player #%d" % seat
		_send_ping(delta)
	ping_label.text = ("ping: %.0fms" % ping_ms) if ping_ms >= 0.0 else "ping: --"
	timer_label.text = ("%ds" % seconds_left) if phase == 1 else ""
	question_label.text = question_text if phase != 2 else "%s\n(correct answer highlighted below)" % question_text

	for i in range(4):
		var btn: Button = option_buttons[i]
		btn.text = options[i]
		btn.disabled = (phase != 1) or locked_out or seat < 0
		if phase == 2 and i == correct_idx:
			btn.modulate = Color(0.3, 1.0, 0.4)
		else:
			btn.modulate = Color(1, 1, 1)

	var score_txt := "Scores  "
	for i in range(4):
		score_txt += "P%d:%d  " % [i, scores[i]]
	scores_label.text = score_txt

func _try_join(delta: float) -> void:
	time_since_join_attempt += delta
	if time_since_join_attempt < JOIN_RETRY_INTERVAL:
		return
	if join_attempts >= JOIN_MAX_ATTEMPTS:
		status_label.text = "No response from the room."
		awaiting_welcome = false
		return
	udp.put_packet("JOIN\n".to_utf8_buffer())
	join_attempts += 1
	time_since_join_attempt = 0.0

func _send_ping(delta: float) -> void:
	time_since_ping += delta
	if time_since_ping < PING_INTERVAL:
		return
	time_since_ping = 0.0
	ping_sent_at_msec = Time.get_ticks_msec()
	ping_awaiting = true
	udp.put_packet(("PING,%d\n" % seat).to_utf8_buffer())

func _handle_line(line: String) -> void:
	var parts := line.split(",")
	match parts[0]:
		"PONG":
			if ping_awaiting:
				ping_ms = float(Time.get_ticks_msec() - ping_sent_at_msec)
				ping_awaiting = false
		"WELCOME":
			seat = int(parts[1])
			awaiting_welcome = false
			status_label.text = ""
		"FULL":
			awaiting_welcome = false
			status_label.text = "Room is full."
		"QUESTION":
			question_text = parts[2]
			for i in range(4):
				options[i] = parts[3 + i] if parts.size() > 3 + i else ""
			phase = 1
			correct_idx = -1
			locked_out = false
			last_result_text = ""
		"CORRECT":
			var who := int(parts[1])
			correct_idx = int(parts[2])
			phase = 2
			last_result_text = "Nobody got it in time!" if who < 0 else ("Player %d got it!" % who)
			status_label.text = last_result_text
		"WRONG":
			locked_out = true
			status_label.text = "Not quite -- others can still buzz in."
		"STATE":
			if parts.size() > 3:
				phase = int(parts[1])
				seconds_left = int(parts[2])
				var score_parts: PackedStringArray = parts[3].split(",")
				for i in range(4):
					if i < score_parts.size() and score_parts[i] != "":
						scores[i] = int(score_parts[i])
		"OPPONENT_LEFT":
			status_label.text = "A player left."

func _on_option_pressed(idx: int) -> void:
	if seat < 0 or phase != 1 or locked_out:
		return
	udp.put_packet(("IN,%d,%d\n" % [seat, idx]).to_utf8_buffer())
